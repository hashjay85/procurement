<?php include("includes/a_config.php");?>
<?php 
include("includes/conn.php");
include("includes/sessionconfig.php");
?>
<?php

$cur_dte=date("Y-m-d");

?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
	
	<link rel="stylesheet" type="text/css" href="datatable/dataTables.min.css"/>
	<link rel="stylesheet" type="text/css" href="datatable/jquery-ui.css"/>
	<script type="text/javascript" src="datatable/dataTables.min.js"></script> 
	
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	
	<h2>Welcome Procurement Management System</h2>
	<p>This project was developped for the university of Colombo School of computing</p>

	<p> Main Expectation of this System is to simplify the Procurementsystem and systematic the same. Through the system we are expecting to evaluate BOQs, Products and servives </p>
	
	<div class="row">
		<div class="col-md-12">
			<section class="panel panel-primary  panel-transparent ">
				 <div class="panel-heading">
					<label style="font-size:20px;">Initialize Projects </label>
				 </div>
				<div class="panel-body">
					
						<table id="tb1" class="display" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</tfoot>
								<tbody>
									<?php
										$sql1="SELECT * FROM project_master WHERE expire_dte>='$cur_dte' AND status=0";
										$result1 = mysqli_query($link ,$sql1);
										while($row1=mysqli_fetch_array($result1)){
												
											$sql2="SELECT * FROM boq_master WHERE projmas_key='$row1[projmas_key]' AND status=0";
											$result2 = mysqli_query($link ,$sql2);
											if(mysqli_num_rows($result2)==0){
									?>	
											<tr>
												<td width="20%"><a href="ncb_move.php?p=<?php echo $row1['projmas_key']; ?>&t=<?php echo $row1['bid_type']; ?>"><?php echo $row1['project_id']; ?></a></td>
												<td width="20%"><?php echo $row1['project_nme']; ?></td>
												<td width="20%"><?php echo $row1['bid_type']; ?></td>
												<td width="20%"><?php echo $row1['expire_dte']." ".$row1['exp_time']; ?></td>
												<td width="20%" align="right"><?php echo number_format($row1['valueofbid_sec'],2); ?></td>
											</tr>	
									<?php
											}
										}
									?>
								</tbody>
						</table>
				</div>
			</section>
		</div>
	</div>
	<!--initialize Projects-->
	
	<div class="row">
		<div class="col-md-12">
			<section class="panel panel-success  panel-transparent ">
				 <div class="panel-heading">
					<label style="font-size:20px;">Process Projects </label>
				 </div>
				<div class="panel-body">
					
						<table id="tb2" class="display" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</tfoot>
								<tbody>
									<?php
										$sql3="SELECT * FROM project_master WHERE expire_dte>='$cur_dte' AND status=0";
										$result3 = mysqli_query($link ,$sql3);
										while($row3=mysqli_fetch_array($result3)){
												
											$sql4="SELECT * FROM boq_master WHERE projmas_key='$row3[projmas_key]' AND status=0";
											$result4 = mysqli_query($link ,$sql4);
											if(mysqli_num_rows($result4)>1){
									?>	
											<tr>
												<td width="20%"><a href="ncb_move.php?p=<?php echo $row3['projmas_key']; ?>&t=<?php echo $row3['bid_type']; ?>"><?php echo $row3['project_id']; ?></a></td>
												<td width="20%"><?php echo $row3['project_nme']; ?></td>
												<td width="20%"><?php echo $row3['bid_type']; ?></td>
												<td width="20%"><?php echo $row3['expire_dte']." ".$row3['exp_time']; ?></td>
												<td width="20%" align="right"><?php echo number_format($row3['valueofbid_sec'],2); ?></td>
											</tr>	
									<?php
											}
										}
									?>
								</tbody>
						</table>
				</div>
			</section>
		</div>
	</div>
	<!--Process Projects-->
	
	<div class="row">
		<div class="col-md-12">
			<section class="panel panel-danger  panel-transparent ">
				 <div class="panel-heading">
					<label style="font-size:20px;">Expire Projects </label>
				 </div>
				<div class="panel-body">
					
						<table id="tb3" class="display" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th width="20%">Project ID</th>
										<th width="20%">Project Name</th>
										<th width="20%">Bid Type</th>
										<th width="20%">Expire Date</th>
										<th width="10%">Value</th>
									</tr>
								</tfoot>
								<tbody>
									<?php
										$sql5="SELECT * FROM project_master WHERE expire_dte<='$cur_dte' AND status=0";
										$result5 = mysqli_query($link ,$sql5);
										while($row5=mysqli_fetch_array($result5)){
										
									?>	
											<tr>
												<td width="20%"><a href="ncb_move.php?p=<?php echo $row5['projmas_key']; ?>&t=<?php echo $row5['bid_type'];?>"><?php echo $row5['project_id']; ?></a></td>
												<td width="20%"><?php echo $row5['project_nme']; ?></td>
												<td width="20%"><?php echo $row5['bid_type']; ?></td>
												<td width="20%"><?php echo $row5['expire_dte']." ".$row5['exp_time']; ?></td>
												<td width="20%" align="right"><?php echo number_format($row5['valueofbid_sec'],2); ?></td>
											</tr>	
									<?php
											
										}
									?>
								</tbody>
						</table>
				</div>
			</section>
		</div>
	</div>
	<!--Expire Projects-->
</div>

<?php include("includes/footer.php");?>



<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
					$('#tb1 tfoot th').each( function () {
							var title = $(this).text();
							$(this).html( '<input type="text" placeholder="'+title+'" style="color:black" class="form-control input-sm" />' );
						} );
					 
						// DataTable
						var table = $('#tb1').DataTable();
					 
						// Apply the search
						table.columns().every( function () {
							var that = this;
					 
							$( 'input', this.footer() ).on( 'keyup change', function () {
								if ( that.search() !== this.value ) {
									that
										.search( this.value )
										.draw();
								}
							} );
						} );
//............................................................. table 1 Jaquery
					$('#tb2 tfoot th').each( function () {
							var title = $(this).text();
							$(this).html( '<input type="text" placeholder="'+title+'" style="color:black" class="form-control input-sm" />' );
						} );
					 
						// DataTable
						var table = $('#tb2').DataTable();
					 
						// Apply the search
						table.columns().every( function () {
							var that = this;
					 
							$( 'input', this.footer() ).on( 'keyup change', function () {
								if ( that.search() !== this.value ) {
									that
										.search( this.value )
										.draw();
								}
							} );
						} );
//............................................................. table 2 Jaquery
						$('#tb3 tfoot th').each( function () {
							var title = $(this).text();
							$(this).html( '<input type="text" placeholder="'+title+'" style="color:black" class="form-control input-sm" />' );
						} );
					 
						// DataTable
						var table = $('#tb3').DataTable();
					 
						// Apply the search
						table.columns().every( function () {
							var that = this;
					 
							$( 'input', this.footer() ).on( 'keyup change', function () {
								if ( that.search() !== this.value ) {
									that
										.search( this.value )
										.draw();
								}
							} );
						} );
//............................................................. table 3 Jaquery
			});
</script>
</body>
</html>