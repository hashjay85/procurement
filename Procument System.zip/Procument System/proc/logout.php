<?php
session_start();

unset($_SESSION['login_user']);
unset($_SESSION['user_level']);
unset($_SESSION['dep']);
unset($_SESSION['committ']);
unset($_SESSION['user_keye']);

session_destroy();

header("location:index.php");

exit;
?>