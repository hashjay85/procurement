# Number To Words — Roadmap

### Version 2.0
- Rework the API
- Add pluggable languages files for multi-language support
- Remove 1.x deprecated code
- Run tests with Karma
