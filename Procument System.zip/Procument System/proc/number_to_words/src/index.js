'use strict'; 

module.exports = {
    toOrdinal: require('./toOrdinal'),
    toWords: require('./toWords'),
    toWordsOrdinal: require('./toWordsOrdinal')
};
