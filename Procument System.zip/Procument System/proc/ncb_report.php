<?php
 ob_start();
 $cur_dte=date("Y-m-d");
	include("includes/conn.php");
	$sql1="SELECT * FROM ncb_details WHERE project_key='$_GET[p]' AND status=0";
	$result1 = mysqli_query($link,$sql1);
	while($row1=mysqli_fetch_array($result1)){	
			$a40=$row1['sec2_itb1_1'];
			$projid=$row1['sec2_itb1_1_tenderno'];
			$a42=$row1['sec2_itb2_1'];
			$a43=$row1['sec2_itb4_4'];
			$a44=$row1['sec2_itb7_1_attention'];
			$a45=$row1['sec2_itb7_1_address'];
			$a46=$row1['sec2_itb7_1_telephone'];
			$a47=$row1['sec2_itb7_1_facimaileno'];
			$a48=$row1['sec2_itb7_1_Eelectornicmail'];
			$a49=$row1['no_of_lots'];
			$a50=$row1['sec2_itb11_1e'];
			$a51=$row1['sec2_itb14_3'];
			$a52=$row1['sec2_itb15_1'];
			$a53=$row1['sec2_itb17_3'];
			$a54=$row1['sec2_itb18_1b'];
			$a55=$row1['sec2_itb19_1'];
			$a56=$row1['sec2_itb20_2'];
			$a57=$row1['sec2_itb20_2_date'];
			$a58=$row1['sec2_itb22_2c'];
			$a59=$row1['sec2_itb23_1_date'];
			$a60=$row1['sec2_itb23_1_time'];
			$a61=$row1['sec2_itb26_1_address'];
			$a62=$row1['sec2_itb26_1_date'];
			$a63=$row1['sec2_itb26_1_time'];
			$a64=$row1['sec2_itb35_4'];
			$a65=$row1['sec2_itb35_5'];
			$a100=$row1['procument_title'];
			
			//Section 1
			
			$a66=$row1['sec3_fincapable'];
			// Section 3
			
			$a67=$row1['sec4_dte'];
			$a68=$row1['sec4_no'];
			// Section 4
			
			$a69=$row1['sec5_manufacturedte'];
			$a70=$row1['sec5_manufactureprocess'];
			$a71=$row1['sec5_nameofmanufactor'];
			$a72=$row1['sec5_typeofmanufactor'];
			$a73=$row1['sec5_fulladdressmanufactor'];
			$a74=$row1['sec5_completenmeofbidder'];
			$a75=$row1['sec5_title'];
			$a76=$row1['sec5_dteofsign'];
			$a77=$row1['sec5_nameofauthperson'];
			$a78=$row1['sec5_discreptionofgood'];
			// Section 5
			
			$a80=$row1['sec7_conagreementdayofno'];
			$a81=$row1['sec7_conagreementmon'];
			$a82=$row1['sec7_conagreementyer'];
			$a83=$row1['sec7_nameofpurchaser'];
			$a84=$row1['sec7_discriptionlegal'];
			$a85=$row1['sec7_nmeofsupplier'];
			$a86=$row1['sec7_addressofsupplier'];
			$a87=$row1['sec7_bri_dis_serv_purc'];
			$a88=$row1['sec7_contractprice'];
			$a89=$row1['sec7_refnoofcontract'];
			$a90=$row1['sec7_contrctdte'];
			$a91=$row1['sec7_briefdescontract'];
			$a92=$row1['sec7_profomanceguranteeno'];
			$a93=$row1['sec7_nmeadressissueagancy'];
			$a94=$row1['sec7_nameadrresofemp'];
			$a95=$row1['sec7_payamount'];
			$a96=$row1['sec7_gexedayofno'];
			$a97=$row1['sec7_gexemon'];
			$a98=$row1['sec7_gexeyer'];
			$a99=$row1['sec7_contryofsupplier'];
			// Section 7
	}
	
	$sql10="SELECT * FROM project_master WHERE projmas_key='$_GET[p]' AND status=0";
	$result10 = mysqli_query($link,$sql10);
	while($row10=mysqli_fetch_array($result10)){
		$projid=$row10['project_id'];
	}
	
	function convertNumber($num = false)
		{
			$num = str_replace(array(',', ''), '' , trim($num));
			if(! $num) {
				return false;
			}
			$num = (int) $num;
			$words = array();
			$list1 = array('', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
				'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'
			);
			$list2 = array('', 'ten', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred');
			$list3 = array('', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'quintillion', 'sextillion', 'septillion',
				'octillion', 'nonillion', 'decillion', 'undecillion', 'duodecillion', 'tredecillion', 'quattuordecillion',
				'quindecillion', 'sexdecillion', 'septendecillion', 'octodecillion', 'novemdecillion', 'vigintillion'
			);
			$num_length = strlen($num);
			$levels = (int) (($num_length + 2) / 3);
			$max_length = $levels * 3;
			$num = substr('00' . $num, -$max_length);
			$num_levels = str_split($num, 3);
			for ($i = 0; $i < count($num_levels); $i++) {
				$levels--;
				$hundreds = (int) ($num_levels[$i] / 100);
				$hundreds = ($hundreds ? ' ' . $list1[$hundreds] . ' hundred' . ( $hundreds == 1 ? '' : '' ) . ' ' : '');
				$tens = (int) ($num_levels[$i] % 100);
				$singles = '';
				if ( $tens < 20 ) {
					$tens = ($tens ? ' and ' . $list1[$tens] . ' ' : '' );
				} elseif ($tens >= 20) {
					$tens = (int)($tens / 10);
					$tens = ' and ' . $list2[$tens] . ' ';
					$singles = (int) ($num_levels[$i] % 10);
					$singles = ' ' . $list1[$singles] . ' ';
				}
				$words[] = $hundreds . $tens . $singles . ( ( $levels && ( int ) ( $num_levels[$i] ) ) ? ' ' . $list3[$levels] . ' ' : '' );
			} //end for loop
			$commas = count($words);
			if ($commas > 1) {
				$commas = $commas - 1;
			}
			$words = implode(' ',  $words);
			$words = preg_replace('/^\s\b(and)/', '', $words );
			$words = trim($words);
			$words = ucfirst($words);
			$words = $words;
			return $words;
		}
?> 


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-1252">
</head>
	<script type="text/javascript" src="number_to_words/numberToWords.min.js"></script>
<body>

<h1 align="center" style="font-size:40px;font-weight:bold;">University of Colombo School of Computing</h1>

<div align="center"><img src="gv.png" width="15%" height="20%"></div>
<br>
<div align="center" style="font-size:25px;font-weight:bold;">BIDDING DOCUMENT</div><br>
<div align="center" style="font-size:20px;font-weight:bold;">FOR</div><br>

<div align="center" style="font-size:25px;font-weight:bold;"><?php echo $projid; ?></div>
<br>
<br>
<br>
<br>
<br>
<br>

<div><img src="gv.png" width="15%" height="20%"></div>
<div style="font-size:18px;font-weight:bold;">Chairman DPC</div>
<div style="font-size:18px;font-weight:bold;">University of Colombo School of Computing</div>
<div style="font-size:18px;font-weight:bold;">No. 35 Reid Avenue Colombo 00700. </div>
<div align="right" style="font-size:14px;">NPA/Goods/SBD 01 </div>
<br style="page-break-before: always">
<!-- 1 st page End -->

<h1 align="center" style="font-size:40px;font-weight:bold;">THIS PAGE PURPOSELY LEFT BLANK</h1>
<br style="page-break-before: always">


<!-- 2nd page End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section I Instructions to Bidders</h1>

<p>ITB shall be read in conjunction with the Section II, Bidding Data Sheet (BDS), which shall take precedence over ITB.</p>

<div style="font-size:18px;">General</div>

<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
	<tbody>
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">1. Scope of Bid</td>
			<td width="80%" style="text-align:justify;">
				<p>1.1 The Purchaser indicated in the Bidding Data Sheet (BDS), issues these Bidding Documents for the supply of Goods and Related Services incidental thereto as specified in Section V, Schedule of Requirements. The name and identification number of this procurement are specified in the BDS. The name, identification, and number of lots (individual contracts), if any, are provided in the BDS.</p>
				<p>1.2 Throughout these Bidding Documents:</p> 
				<p>(a) the term &quot;in writing&quot; means communicated in written form by mail (other than electronic mail) or hand delivered with proof of receipt; </p>
				<p>(b) if the context so requires, &quot;singular&quot; means &quot;plural&quot; and vice versa; and </p>
				<p>(c) &quot;day&quot; means calendar day.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">2. Source of Funds</td>
			<td width="80%" style="text-align:justify;">
				<p>2.1 Payments under this contract will be financed by the source specified in the BDS.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">3. Ethics, Fraud and Corruption</td>
			<td width="80%" style="text-align:justify;">
				<p>3.1 The attention of the bidders is drawn to the following guidelines of the Procurement Guidelines published by National Procurement Agency:</p>
				<p>Parties associated with Procurement Actions, namely, suppliers/ contractors and officials shall ensure that they maintain strict confidentiality throughout the process;</p>
				<p>Officials shall refrain from receiving any personal gain from any Procurement Action. No gifts or inducement shall be accepted. Suppliers/contractors are liable to be disqualified from the bidding process if found offering any gift or inducement which may have an effect of influencing a decision or impairing the objectivity of an official.</p>
				<p>(a) &quot;corrupt practice&quot; means the offering, giving, receiving, or soliciting, directly or indirectly, of anything of value to influence the action of a public official in the procurement process or in contract execution</p>
				<p>(b) &quot;fraudulent practice&quot; means a misrepresentation or omission of facts in order to influence a procurement process or the execution of a contract;</p>
				<p>c) &quot;collusive practice&quot; means a scheme or arrangement between two or more bidders, with or without the knowledge of the Purchaser to establish bid prices at artificial, noncompetitive levels; and</p>
				<p>(d) &quot;coercive practice&quot; means harming or threatening to harm, directly or indirectly, persons or their property to influence their participation in the procurement process or affect the execution of a contract.</p>
				<p>3.3 If the Purchaser found any unethical practices as stipulated under ITB Clause 3.2, the Purchaser will reject a bid, if it is found that a Bidder directly or through an agent, engaged in corrupt, fraudulent, collusive or coercive practices in competing for the Contract in question.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">4. Eligible Bidders</td>
			<td width="80%" style="text-align:justify;">
				<p>4.1 All bidders shall possess legal rights to supply the Goods under this contract.</p>
				<p>4.2 A Bidder shall not have a conflict of interest. All bidders found to have conflict of interest shall be disqualified. Bidders may be considered to have a conflict of interest with one or more parties in this bidding process, if they:</p>
				<p>(a) are or have been associated in the past, with a firm or any of its affiliates which have been engaged by the Purchaser to provide consulting services for the preparation of the design, specifications, and other documents to be used for the procurement of the goods to be purchased under these Bidding Documents ; or</p>
				<p>(b) submit more than one bid in this bidding process. However, this does not limit the participation of subcontractors in more than one bid.</p>
				<p>4.3 A Bidder that is under a declaration of ineligibility by the National Procurement Agency (NPA), at the date of submission of bids or at the date of contract award, shall be disqualified. The list of debarred firms is available at the website of NPA, www.npa.gov.lk .</p>
				<p>4.4 Foreign Bidder may submit a bid only if so stated in the in the BDS.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">5. Eligible Goods and Related Services</td>
			<td width="80%" style="text-align:justify;">
				<p>5.1 All goods supplied under this contract shall be complied with applicable standards stipulated by the Sri Lanka Standards Institute (SLSI). In the absence of such standards, the Goods supplied shall be complied to other internationally accepted standards.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p style="font-size:20px;font-weight:bold;">Contents of Bidding Documents</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">6. Sections of Bidding Documents</td>
			<td width="80%" style="text-align:justify;">
				<p>6.1 The Bidding Documents consist of 2 Volumes, which include all the sections indicated below, and should be read in conjunction with any addendum issued in accordance with ITB Clause 8.</p>
				<ul>
				  <li>Section I. Instructions to Bidders (ITB)</li>
				  <li>Section II. Bidding Data Sheet (BDS)</li>
				  <li>Section III. Evaluation and Qualification Criteria</li>
				  <li>Section IV. Bidding Forms</li>
				  <li>Section V. Price Schedule & Specifications</li>
				  <li>Section VI. Conditions of Contract (CC)</li>
				  <li>Section VII. Contract Data</li>
				  <li>Section VIII. Contract Forms</li>
				  <li>Invitation For Bid</li>
				</ul> 
				<p>6.2 The Bidder is expected to examine all instructions, forms, terms, and specifications in the Bidding Documents. Failure to furnish all information or documentation required by the Bidding Documents may result in the rejection of the bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">7. Clarification of Bidding Documents</td>
			<td width="80%" style="text-align:justify;">
				<p>7.1 A prospective Bidder requiring any clarification of the Bidding Documents including the restrictiveness of specifications shall contact the Purchaser in writing at the Purchaser&#39;s address specified in the BDS. The Purchaser will respond in writing to any request for clarification, provided that such request is received no later than ten (10) days prior to the deadline for submission of bids. The Purchaser shall forward copies of its response to all those who have purchased the Bidding Documents, including a description of the inquiry but without identifying its source. Should the Purchaser deem it necessary to amend the Bidding Documents as a result of a clarification, it shall do so following the procedure under ITB Clause 8.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">8. Amendment of Bidding Documents</td>
			<td width="80%" style="text-align:justify;">
				<p>8.1 At any time prior to the deadline for submission of bids, the Purchaser may amend the Bidding Documents by issuing addendum.</p>
				<p>8.2 Any addendum issued shall be part of the Bidding Documents and shall be communicated in writing to all who have purchased the Bidding Documents.</p>
				<p>8.3 To give prospective Bidders reasonable time in which to take an addendum into account in preparing their bids, the Purchaser may, at its discretion, extend the deadline for the submission of bids, pursuant to ITB Sub-Clause 23.2</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">9. Cost of Bidding</td>
			<td width="80%" style="text-align:justify;">
				<p>9.1 The Bidder shall bear all costs associated with the preparation and submission of its bid, and the Purchaser shall not be responsible or liable for those costs, regardless of the conduct or outcome of the bidding process.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">10. Language of Bid</td>
			<td width="80%" style="text-align:justify;">
				<p>10.1 The Bid, as well as all correspondence and documents relating to the Bid (including supporting documents and printed literature) exchanged by the Bidder and the Purchaser, shall be written in English language.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">11. Documents Comprising the Bid</td>
			<td width="80%" style="text-align:justify;">
				<p>11.1 The Bid shall comprise the following:</p>
				<p>(a) Bid Submission Form and the applicable Price Schedules, in accordance with ITB Clauses 12, 14, and 15;</p>
				<p>(b) Bid Security in accordance with ITB Clause 20;</p>
				<p>(c) documentary evidence in accordance with ITB Clauses 18 and 29, that the Goods and Related Services conform to the Bidding Documents;</p>
				<p>(d) documentary evidence in accordance with ITB Clause 18 establishing the Bidders qualifications to perform the contract if its bid is accepted; and</p>
				<p>(e) any other document required in the BDS.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">12. Bid Submission Form and Price Schedules</td>
			<td width="80%" style="text-align:justify;">
				<p>12.1 The Bidder shall submit the Bid Submission Form using the form furnished in Section IV, Bidding Forms. This form must be completed without any alterations to its format, and no substitutes shall be accepted. All blank spaces shall be filled in with the information requested.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">13. Alternative Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>13.1 Alternative bids shall not be considered.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">14. Bid Prices and Discounts</td>
			<td width="80%" style="text-align:justify;">
				<p>14.1 The Bidder shall indicate on the Price Schedule the unit prices and total bid prices of the goods it proposes to supply under the Contract.</p>
				<p>14.2 Any discount offered against any single item in the price schedule shall be included in the unit price of the item. However, a Bidder wishes to offer discount as a lot the bidder may do so by indicating such amounts appropriately.</p>
				<p>14.3 If so indicated in ITB Sub-Clause 1.1, bids are being invited for individual contracts (lots) or for any combination of contracts (packages). Unless otherwise indicated in the BDS, prices quoted shall correspond to 100 % of the items specified for each lot and to 100% of the quantities specified for each item of a lot. Bidders wishing to offer any price reduction (discount) for the award of more than one Contract shall specify the applicable price reduction separately.</p>
				<p>14.4 (i) Prices indicated on the Price Schedule shall include all duties and sales and other taxes already paid or payable by the Supplier:</p>
				<p>(a) on components and raw material used in the manufacture or assembly of goods quoted; or</p>
				<p>(b) on the previously imported goods of foreign origin.</p>
				<p>(ii) However, VAT shall not be included in the price but shall be indicated separately;</p>
				<p>(iii) the price for inland transportation, insurance and other related services to deliver the goods to their final destination;</p>
				<p>(iv) the price of other incidental services</p>
				<p>14.5 The Prices quoted by the Bidder shall be fixed during the Bidder's performance of the Contract and not subject to variation on any account. A bid submitted with an adjustable price quotation will be treated as non-responsive and rejected, pursuant to ITB Clause 31.</p>
				<p>14.6 All lots, if any, and items must be listed and priced separately in the Price Schedules. If a Price Schedule shows items listed but not priced, their prices shall be assumed to be included in the prices of other items.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">15. Currencies of Bid</td>
			<td width="80%" style="text-align:justify;">
				<p>15.1 Unless otherwise stated in Bidding Data Sheet, the Bidder shall quote in Sri Lankan Rupees and payment shall be payable only in Sri Lanka Rupees.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">16. Documents Establishing the Eligibility of the Bidder</td>
			<td width="80%" style="text-align:justify;">
				<p>16.1 To establish their eligibility in accordance with ITB Clause 4, Bidders shall complete the Bid Submission Form, included in Section IV, Bidding Forms.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">17. Documents Establishing the Conformity of the Goods and Related Services</td>
			<td width="80%" style="text-align:justify;">
				<p>17.1 To establish the conformity of the Goods and Related Services to the Bidding Documents, the Bidder shall furnish as part of its Bid the documentary evidence that the Goods conform to the technical specifications and standards specified in Section V, Schedule of Requirements.</p>
				<p>17.2 The documentary evidence may be in the form of literature, drawings or data, and shall consist of a detailed item by item description (given in Section V, Technical Specifications) of the essential technical and performance characteristics of the Goods and Related Services, demonstrating substantial responsiveness of the Goods and Related Services to the technical specification, and if applicable, a statement of deviations and exceptions to the provisions of the Schedule of Requirements.</p>
				<p>17.3 The Bidder shall also furnish a list giving full particulars, including quantities, available sources and current prices of spare parts, special tools, etc., necessary for the proper and continuing functioning of the Goods during the period if specified in the BDS following commencement of the use of the goods by the Purchaser.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">18. Documents Establishing the Qualifications of the Bidder</td>
			<td width="80%" style="text-align:justify;">
				<p>18.1 The documentary evidence of the Bidder&#39;s qualifications to perform the contract if its bid is accepted shall establish to the Purchaser&#39;s satisfaction:</p>
				<p>(a) A Bidder that does not manufacture or produce the Goods it offers to supply shall submit the Manufacturer&#39;s Authorization using the form included in Section IV, Bidding Forms to demonstrate that it has been duly authorized by the manufacturer or producer of the Goods to supply these Goods;</p>
				<p>(b) that, if required in the BDS, in case of a Bidder not doing business within Sri Lanka, the Bidder is or will be (if awarded the contract) represented by an Agent in Sri Lanka equipped and able to carry out the Supplier&#39;s maintenance, repair and spare parts stocking obligations prescribed in the Conditions of Contract and/or Technical Specifications; and</p>
				<p>(c) that the Bidder meets each of the qualification criterion specified in Section III, Evaluation and Qualification Criteria.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">19. Period of Validity of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>19.1 Bids shall remain valid until the date specified in the BDS. A bid valid for a shorter date shall be rejected by the Purchaser as non responsive.</p>
				<p>19.2 In exceptional circumstances, prior to the expiration of the bid validity date, the Purchaser may request bidders to extend the period of validity of their bids. The request and the responses shall be made in writing. If a Bid Security is requested in accordance with ITB Clause 20, it shall also be extended for a corresponding period. A Bidder may refuse the request without forfeiting its Bid Security. A Bidder granting the request shall not be required or permitted to modify its bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">20. Bid Security</td>
			<td width="80%" style="text-align:justify;">
				<p>20.1 The Bidder shall furnish as part of its bid, a Bid Security or a Bid-Securing Declaration, as specified in the BDS.</p>
				<p>20.2 The Bid Security shall be in the amount specified in the BDS and denominated in Sri Lanka Rupees, and shall:</p>
				<p>(a) at the bidder&#39;s option, be in the form of either a bank draft, a letter of credit, or a bank guarantee from a banking institution;</p>
				<p>(b) be issued by a institution acceptable to Purchaser. The acceptable institutes are published in the NPA website, www.npa.gov.lk.</p>
				<p>(c) be substantially in accordance with the form included in Section IV, Bidding Forms;</p>
				<p>(d) be payable promptly upon written demand by the Purchaser in case the conditions listed in ITB Clause 20.5 are invoked;</p>
				<p>(e) be submitted in its original form; copies will not be accepted;</p>
				<p>(f) remain valid for the period specified in the BDS.</p>
				<p>20.3 Any bid not accompanied by a substantially responsive Bid Security in accordance with ITB Sub-Clause 20.1 and 20.2, may be rejected by the Purchaser as non-responsive.</p>
				<p>20.4 The Bid Security of unsuccessful Bidders shall be returned as promptly as possible upon the successful Bidder&#39;s furnishing of the Performance Security pursuant to ITB Clause 43.</p>
				<p>20.5 The Bid Security may be forfeited or the Bid Securing Declaration executed:</p>
				<p>(a) if a Bidder withdraws its bid during the period of bid validity specified by the Bidder on the Bid Submission Form, except as provided in ITB Sub-Clause 19.2; or</p>
				<p>(b) if a Bidder does not agreeing to correction of arithmetical errors in pursuant to ITB Sub-Clause 30.3</p>
				<p>(c) if the successful Bidder fails to:</p>
				<p>(i) sign the Contract in accordance with ITB Clause 42;</p>
				<p>(ii) furnish a Performance Security in accordance with ITB Clause 43.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">21. Format and Signing of Bid</td>
			<td width="80%" style="text-align:justify;">
				<p>21.1 The Bidder shall prepare one original of the documents comprising the bid as described in ITB Clause 11 and clearly mark it as &quot;ORIGINAL.&quot; In addition, the Bidder shall submit a copy of the bid and clearly mark it as &quot;COPY.&quot; In the event of any discrepancy between the original and the copy, the original shall prevail.</p>
				<p>21.2 The original and the Copy of the bid shall be typed or written in indelible ink and shall be signed by a person duly authorized to sign on behalf of the Bidder.</p>
				<p>21.3 Any internalizations, erasures, or overwriting shall be valid only if they are signed or initialed by the person signing the Bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p style="font-size:20px;font-weight:bold;">Submission and Opening of Bids</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">22. Submission, Sealing and Marking of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>22.1 Bidders may always submit their bids by mail or by hand.</p>
				<p>(a) Bidders submitting bids by mail or by hand, shall enclose the original and the copy of the Bid in separate sealed envelopes, duly marking the envelopes as &quot;ORIGINAL&quot; and &quot;COPY.&quot; These envelopes containing the original and the copy shall then be enclosed in one single envelope.</p>
				<p>22.2 The inner and outer envelopes shall:</p>
				<p>(a) Bear the name and address of the Bidder;</p>
				<p>(b) be addressed to the Purchaser in accordance with ITB Sub-Clause 23.1;</p>
				<p>(c) bear the specific identification of this bidding process as indicated in the BDS; and</p>
				<p>(d) bear a warning not to open before the time and date for bid opening, in accordance with ITB Sub-Clause 261. If all envelopes are not sealed and marked as required, the Purchaser will assume no responsibility for the misplacement or premature opening of the bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">23. Deadline for Submission of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>23.1 Bids must be received by the Purchaser at the address and no later than the date and time specified in the BDS.</p>
				<p>23.2 The Purchaser may, at its discretion, extend the deadline for the submission of bids by amending the Bidding Documents in accordance with ITB Clause 8, in which case all rights and obligations of the Purchaser and Bidders previously subject to the deadline shall thereafter be subject to the deadline as extended.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">24. Late Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>24.1 The Purchaser shall not consider any bid that arrives after the deadline for submission of bids, in accordance with ITB Clause 23. Any bid received by the Purchaser after the deadline for submission of bids shall be declared late, rejected, and returned unopened to the Bidder.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">25. Withdrawal, and Modification of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>25.1 A Bidder may withdraw, or modify its Bid after it has been submitted by sending a written notice in accordance with ITB Clause 22, duly signed by an authorized representative, and shall include a copy of the authorization in accordance with ITB Sub-Clause 21.2, (except that no copies of the withdrawal notice are required). The corresponding substitution or modification of the bid must accompany the respective written notice. All notices must be:</p>
				<p>(a) submitted in accordance with ITB Clauses 21 and 22 (except that withdrawal notices do not require copies), and in addition, the respective envelopes shall be clearly marked &quot;WITHDRAWAL,&quot; or &quot;MODIFICATION;&quot; and</p>
				<p>(b) received by the Purchaser prior to the deadline prescribed for submission of bids, in accordance with ITB Clause 23.</p>
				<p>25.2 Bids requested to be withdrawn in accordance with ITB Sub-Clause 25.1 shall be returned to the Bidders only upon notification of contract award to the successful bidder in accordance with sub clause 41.1.</p>
				<p>25.3 No bid may be withdrawn, substituted, or modified in the interval between the deadline for submission of bids and the expiration of the period of bid validity specified by the Bidder on the Bid Submission Form or any extension thereof.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">26. Bid Opening</td>
			<td width="80%" style="text-align:justify;">
				<p>26.1 The Purchaser shall conduct the bid opening in public at the address, date and time specified in the BDS.</p>
				<p>26.2 First, envelopes marked &quot;WITHDRAWAL&quot; shall be opened and read out and the envelope with the corresponding bid may be opened at the discretion of the Purchaser. No bid withdrawal shall be permitted unless the corresponding withdrawal notice contains a valid authorization to request the withdrawal and is read out at bid opening. Envelopes marked &quot;MODIFICATION&quot; shall be opened and read out with the corresponding Bid. No Bid modification shall be permitted unless the corresponding modification notice contains a valid authorization to request the modification and is read out at Bid opening. Only envelopes that are opened and read out at Bid opening shall be considered further.</p>
				<p>26.3 All other envelopes shall be opened one at a time, reading out: the name of the Bidder and whether there is a modification; the Bid Prices, including any discounts and alternative offers; the presence of a Bid Security or Bid-Securing Declaration, if required; and any other details as the Purchaser may consider appropriate. Only discounts and alternative offers read out at Bid opening shall be considered for evaluation. No Bid shall be rejected at Bid opening except for late bids, in accordance with ITB Sub Section I Clause 24.1.</p>
				<p>26.4 The Purchaser shall prepare a record of the Bid opening that shall include, as a minimum: the name of the Bidder and whether there is a withdrawal, or modification; the Bid Price, per lot if applicable, including any discounts, and the presence or absence of a Bid Security or Bid-Securing Declaration. The bids that were opened shall be resealed in separate envelopes, promptly after the bid opening. The Bidder&#39;s representatives who are present shall be requested to sign the attendance sheet. A copy of the record shall be distributed to all Bidders who submitted bids in time.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p style="font-size:20px;font-weight:bold;">Evaluation and Comparison of Bids</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">27. Confidentiality</td>
			<td width="80%" style="text-align:justify;">
				<p>27.1 Information relating to the examination, evaluation, comparison, and post-qualification (if applicable) of bids, and recommendation of contract award, shall not be disclosed to bidders or any other persons not officially concerned with such process until publication of the Contract Award.</p>
				<p>27.2 Any effort by a Bidder to influence the Purchaser in the examination, evaluation, comparison, and post-qualification of the bids or contract award decisions may result in the rejection of its Bid.</p>
				<p>27.3 Notwithstanding ITB Sub-Clause 27.2, if any Bidder wishes to contact the Purchaser on any matter related to the bidding process, from the time of bid opening to the time of Contract Award, it should do so in writing.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">28. Clarification of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>28.1 To assist in the examination, evaluation, comparison and post-qualification of the bids, the Purchaser may, at its discretion, request any Bidder for a clarification of its Bid. Any clarification submitted by a Bidder in respect to its Bid and that is not in response to a request by the Purchaser shall not be considered for purpose of evaluation. The Purchaser&#39;s request for clarification and the response shall be in writing. No change in the prices or substance of the Bid shall be sought, offered, or permitted, except to confirm the correction of arithmetic errors discovered by the Purchaser in the Evaluation of the bids, in accordance with ITB Clause 30.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">29. Responsiveness of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>29.1 The Purchaser&#39;s determination of a bid&#39;s responsiveness is to be based on the contents of the bid itself.</p>
				<p>29.2 A substantially responsive Bid is one that conforms to all the terms, conditions, and specifications of the Bidding Documents without material deviation, reservation, or omission. A material deviation, reservation, or omission is one that:</p>
				<p>(a) affects in any substantial way the scope, quality, or performance of the Goods and Related Services specified in the Contract; or</p>
				<p>(b) limits in any substantial way, inconsistent with the Bidding Documents, the Purchaser&#39;s rights or the Bidder&#39;s obligations under the Contract; or</p>
				<p>(c) if rectified would unfairly affect the competitive position of other bidders presenting substantially responsive bids.</p>
				<p>29.3 If a bid is not substantially responsive to the Bidding Documents, it shall be rejected by the Purchaser and may not subsequently be made responsive by the Bidder by correction of the material deviation, reservation, or omission.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">30. Nonconformities, Errors, and Omissions</td>
			<td width="80%" style="text-align:justify;">
				<p>30.1 Provided that a Bid is substantially responsive, the Purchaser may waive any non conformities or omissions in the Bid that do not constitute a material deviation.</p>
				<p>30.2 Provided that a bid is substantially responsive, the Purchaser may request that the Bidder submit the necessary information or documentation, within a reasonable period of time, to rectify nonmaterial nonconformities or omissions in the bid related to documentation requirements. Such omission shall not be related to any aspect of the price of the Bid. Failure of the Bidder to comply with the request may result in the rejection of its Bid.</p>
				<p>30.3 Provided that the Bid is substantially responsive, the Purchaser shall correct arithmetical errors on the following basis:</p>
				<p>(a) if there is a discrepancy between the unit price and the line item total that is obtained by multiplying the unit price by the quantity, the unit price shall prevail and the line item total shall be corrected, unless in the opinion of the Purchaser there is an obvious misplacement of the decimal point in the unit price, in which case the line item total as quoted shall govern and the unit price shall be corrected;</p>
				<p>(b) if there is an error in a total corresponding to the addition or subtraction of subtotals, the subtotals shall prevail and the total shall be corrected; and</p>
				<p>(c) if there is a discrepancy between words and figures, the amount in words shall prevail, unless the amount expressed in words is related to an arithmetic error, in which case the amount in figures shall prevail subject to (a) and (b) above.</p>
				<p>30.4 If the Bidder that submitted the lowest evaluated Bid does not accept the correction of errors, its Bid shall be disqualified and its Bid Security shall be forfeited or its Bid-Securing Declaration shall be executed.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">31. Preliminary Examination of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>31.1 The Purchaser shall examine the bids to confirm that all documents and technical documentation requested in ITB Clause 11 have been provided, and to determine the completeness of each document submitted.</p>
				<p>31.2 The Purchaser shall confirm that the following documents and information have been provided in the Bid. If any of these documents or information is missing, the Bid shall be rejected.</p>
				<p>(a) Bid Submission Form, in accordance with ITB Sub-Clause 12.1;</p>
				<p>(b) Price Schedules, in accordance with ITB Sub-Clause 12;</p>
				<p>(c) Bid Security in accordance with ITB Clause 20.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">32. Examination of Terms and Conditions; Technical Evaluation</td>
			<td width="80%" style="text-align:justify;">
				<p>32.1 The Purchaser shall examine the Bid to confirm that all terms and conditions specified in the CC and the Contract Data have been accepted by the Bidder without any material deviation or reservation.</p>
				<p>32.2 The Purchaser shall evaluate the technical aspects of the Bid submitted in accordance with ITB Clause 17, to confirm that all requirements specified in Section V, Schedule of Requirements of the Bidding Documents have been met without any material deviation or reservation.</p>
				<p>32.3 If, after the examination of the terms and conditions and the technical evaluation, the Purchaser determines that the Bid is not substantially responsive in accordance with ITB Clause 29, the Purchaser shall reject the Bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">33. Conversion to Single Currency</td>
			<td width="80%" style="text-align:justify;">
				<p>33.1 If the bidders are allowed to quote in foreign currencies in accordance with sub clause 15.1, for evaluation and comparison purposes, the Purchaser shall convert all bid prices expressed in foreign currencies in to Sri Lankan Rupees using the selling rates prevailed 28 days prior to closing of bids as published by the Central Bank of Sri Lanka. If this date falls on a public holiday the earliest working day prior to the date shall be applicable.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">34. Domestic Preference</td>
			<td width="80%" style="text-align:justify;">
				<p>34.1 Domestic preference shall be a factor in bid evaluation only if stated in the BDS. If domestic preference shall be a bid evaluation factor, the methodology for calculating the margin of preference and the criteria for its application shall be as specified in Section III, Evaluation and Qualification Criteria.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">35. Evaluation of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>35.1 The Purchaser shall evaluate each bid that has been determined, up to this stage of the evaluation, to be substantially responsive.</p>
				<p>35.2 To evaluate a Bid, the Purchaser shall only use all the factors, methodologies and criteria defined in this ITB Clause 35.</p>
				<p>35.3 To evaluate a Bid, the Purchaser shall consider the following:</p>
				<p>(a) the Bid Price as quoted in accordance with clause 14;</p>
				<p>(b) price adjustment for correction of arithmetic errors in accordance with ITB Sub-Clause 30.3;</p>
				<p>(c) price adjustment due to discounts offered in accordance with ITB Sub-Clause 14.2; and 14.3</p>
				<p>(d) adjustments due to the application of the evaluation criteria specified in the BDS from amongst those set out in Section III, Evaluation and Qualification,Criteria;</p>
				<p>(e) adjustments due to the application of a domestic preference, in accordance with ITB Clause 34 if applicable.</p>
				<p>35.4 The Purchaser&#39;s evaluation of a bid may require the consideration of other factors, in addition to the factors stated in ITB Sub-Clause 35.3, if specified in BDS. These factors may be related to the characteristics, performance, and terms and conditions of purchase of the Goods and Related Services. The effect of the factors selected, if any, shall be expressed in monetary terms to facilitate comparison of bids</p>
				<p>35.5 If so specified in the BDS, these Bidding Documents shall allow Bidders to quote for one or more lots, and shall allow the Purchaser to award one or multiple lots to more than one Bidder. The methodology of evaluation to determine the lowest-evaluated lot combinations, is specified in Section III, Evaluation and Qualification Criteria.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">36. Comparison of Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>36.1 The Purchaser shall compare all substantially responsive bids to determine the lowest evaluated bid, in accordance with ITB Clause 35.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">37. Post qualification of the Bidder</td>
			<td width="80%" style="text-align:justify;">
				<p>37.1 The Purchaser shall determine to its satisfaction whether the Bidder that is selected as having submitted the lowest evaluated and substantially responsive bid is qualified to perform the Contract satisfactorily.</p>
				<p>37.2 The determination shall be based upon an examination of the documentary evidence of the Bidder&#39;s qualifications submitted by the Bidder, pursuant to ITB Clause 18.</p>
				<p>37.3 An affirmative determination shall be a prerequisite for award of the Contract to the Bidder. A negative determination shall result in disqualification of the bid, in which event the Purchaser shall proceed to the next lowest evaluated bid to make a similar determination of that Bidder&#39;s capabilities to perform satisfactorily.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">38. Purchaser&#39;s Right to Accept Any Bid, and to Reject Any or All Bids</td>
			<td width="80%" style="text-align:justify;">
				<p>38.1 The Purchaser reserves the right to accept or reject any bid, and to annul the bidding process and reject all bids at any time prior to contract award, without thereby incurring any liability to Bidders.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p style="font-size:20px;font-weight:bold;">Award of Contract</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">39. Award Criteria</td>
			<td width="80%" style="text-align:justify;">
				<p>39.1 The Purchaser shall award the Contract to the Bidder whose offer has been determined to be the lowest evaluated bid and is substantially responsive to the Bidding Documents, provided further that the Bidder is determined to be qualified to perform the Contract satisfactorily.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">40. Purchaser&#39;s Right to Vary Quantities at Time of Award</td>
			<td width="80%" style="text-align:justify;">
				<p>40.1 At the time the Contract is awarded, the Purchaser reserves the right to increase or decrease the quantity of Goods and Related Services originally specified in Section V, Schedule of Requirements, provided this does not exceed twenty five percent (25%) or one unit whichever is higher and without any change in the unit prices or other terms and conditions of the bid and the Bidding Documents.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">41. Notification of Award</td>
			<td width="80%" style="text-align:justify;">
				<p>41.1 Prior to the expiration of the period of bid validity, the Purchaser shall notify the successful Bidder, in writing, that its Bid has been accepted.</p>
				<p>41.2 Until a formal Contract is prepared and executed, the notification of award shall constitute a binding Contract.</p>
				<p>41.3 Upon the successful Bidder&#39;s furnishing of the signed Contract Form and performance security pursuant to ITB Clause 43, the Purchaser will promptly notify each unsuccessful Bidder and will discharge its bid security, pursuant to ITB Clause 20.4.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">42. Signing of Contract</td>
			<td width="80%" style="text-align:justify;">
				<p>42.1 Within Seven (7) days after notification, the Purchaser shall complete the Agreement, and inform the successful Bidder to sign it.</p>
				<p>42.2 Within Seven (7) days of receipt of such information, the successful Bidder shall sign the Agreement.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">43. Performance Security</td>
			<td width="80%" style="text-align:justify;">
				<p>43.1 Within fourteen (14) days of the receipt of notification of award from the Purchaser, the successful Bidder, if required, shall furnish the Performance Security in accordance with the CC, using for that purpose the Performance Security Form included in Section VIII Contract forms. The Employer shall promptly notify the name of the winning Bidder to each unsuccessful Bidder and discharge the Bid Securities of the unsuccessful bidders pursuant to ITB Sub-Clause 20.4.</p>
				<p>43.2 Failure of the successful Bidder to submit the abovementioned Performance Security or sign the Contract shall constitute sufficient grounds for the annulment of the award and forfeiture of the Bid Security or execution of the Bid-Securing Declaration. In that event the Purchaser may award the Contract to the next lowest evaluated Bidder, whose offer is substantially responsive and is determined by the Purchaser to be qualified to perform the Contract satisfactorily.</p>
			</td>
		</tr>
	</tbody>
</table>


<br style="page-break-before: always">
<!-- Section 1 End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section II. Bidding Data Sheet (BDS)</h1>
<p style="text-align:justify;">The following specific data for the goods to be procured shall complement, supplement or amend the provisions in the Instructions to Bidders (ITB). Whenever there is a conflict, the provisions herein shall prevail over those in ITB.</p>

<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
	<tbody>
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB Clause Reference</td>
			<td width="80%" style="text-align:justify;">
				<p>A. General</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 1.1</td>
			<td width="80%" style="text-align:justify;">
				<p>The Purchaser is : University of Colombo School of Computing</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 1.1</td>
			<td width="80%" style="text-align:justify;">
				<p>The name and identification number of the Contract are:</p>
				<p><?php echo $a40; ?></p>
			
				<p style="font-weight:bold;"> ( Tender No: <?php echo $projid; ?> )</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 2.1</td>
			<td width="80%" style="text-align:justify;">
				<p>The source of funding is : <?php echo $a42; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 4.4</td>
			<td width="80%" style="text-align:justify;">
				<p>Foreign bidders are <?php echo $a43; ?> to participate in bidding:</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p>B. Contents of Bidding Documents</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 7.1</td>
			<td width="80%">
				<p>For clarification of bid purposes only, the Purchaser&#39;s address is:</p>
				<div>Attention:</div>
				<div><?php echo $a44; ?></div>
				<br>
				<div>Address : <div>
		
				<div><?php echo $a45; ?></div>
				<br>
				<div>Telephone : <?php echo $a46; ?></div>
				<div>Facsimile Number:  <?php echo $a47; ?></div>
				<div>Electronic mail Address :   <?php echo $a48; ?></div>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 11.1 (e)</td>
			<td width="80%" style="text-align:justify;">
				<p>The Bidders shall submit the additional documents: <?php echo $a50; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB14.3</td>
			<td width="80%" style="text-align:justify;">
				<p><?php echo $a51; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">IT 15.1</td>
			<td width="80%" style="text-align:justify;">
				<p>The bidder shall quote the local expenditure of the following items in Sri Lankan Rupees Only.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB17.3</td>
			<td width="80%" style="text-align:justify;">
				<p>Period of time the Goods are expected to be functioning (for the purpose of spare parts): <?php echo $a53; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 18.1 (b)</td>
			<td width="80%" style="text-align:justify;">
				<p>After sales service is : <?php echo $a54; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 19.1</td>
			<td width="80%" style="text-align:justify;">
				<p>The bid shall be valid until : <?php echo  date("jS F Y", strtotime($a55));?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 20.1</td>
			<td width="80%" style="text-align:justify;">
				<p>Bid shall be include  a bid security from a reputed bank operating in Sri Lanka registered under central bank  of Sri Lanka</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 20.2</td>
			<td width="80%" style="text-align:justify;">
				<div>The amount of the bid security shall be :</div>
				<div><?php echo $a56; ?></div>
				<br>
				<div style="font-weight:bold;">Bid securities should be submitted separately for each lot </div>
				<div>Bid securities should be in  favor of &quot;Director , University of Colombo School of Computing&quot;</div>
				<div>The validity period of the bid security shall be until : <?php echo  date("jS F Y", strtotime($a57));?></div>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">Itb 22.2 (c)</td>
			<td width="80%" style="text-align:justify;">
				<div>The inner and outer envelopes shall bear the following identification marks: </div>
				<div><?php echo $a58; ?></div>
				<br>
				<div>(Tender No: <?php echo $projid; ?>)</div>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 23.1</td>
			<td width="80%" style="text-align:justify;">
				<div>For bid submission purposes, the purchaser&#39;s address is:</div>
				<br>
				<div>Attention : The Director </div>
				<div>Address : University of Colombo School of Computing</div>
				<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No 35 Reid Avenue Colombo 00700.</div>
				<br>
				<div>The deadline for the submission of bids is :</div>
				<div>Date:   <?php echo date("jS F Y", strtotime($a59));?></div>
				<div>Time :  <?php echo $a60;?></div>
				<div></div>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 26.1</td>
			<td width="80%" style="text-align:justify;">
				<div>The Bid Opening Shall Take Place At:</div>
				<div>Address : </div>
				<div><?php echo $a61; ?></div>
				<div>Date : <?php echo date("jS F Y", strtotime($a62));?></div>
				<br>
				<div>Time : <?php echo $a63;?></div>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top"></td>
			<td width="80%" style="text-align:justify;">
				<p>E. Evaluation and Comparison of Bids</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 34.1</td>
			<td width="80%" style="text-align:justify;">
				<p>Domestic preference shall not be a bid evaluation factor.</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 35.3 (d)</td>
			<td width="80%" style="text-align:justify;">
				<p>The adjustments shall be determined using the following criteria, from amongst those set out in Section III, Evaluation and Qualification Criteria:</p>
				<p>(a)	The cost of major replacement components, mandatory spare parts and service:</p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 35.4</td>
			<td width="80%" style="text-align:justify;">
				<p>The following factors and methodology will be used for evaluation:</p>
				<p><?php echo $a64; ?></p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 35.5</td>
			<td width="80%" style="text-align:justify;">
				<p>Bidders are allowed to <?php echo $a65;?>.. (Refer to Section III Evaluation and Qualification Criteria, for the evaluation methodology, if appropriate)</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 36</td>
			<td width="80%" style="text-align:justify;">
				<p>The Purchaser shall compare all substantially responsive bids to determine the lowest-evaluated bid, in accordance Section I Instructions to Bidders. </p>
			</td>
		</tr>
		
		<tr>
			<td width="20%" style="font-weight:bold;" valign="top">ITB 37.2</td>
			<td width="80%" style="text-align:justify;">
				<p>The determination shall be based upon an examination of  the documentary evidence of the Bidder&#39;s qualifications submitted by the Bidder, pursuant to ITB Clause 18</p>
			</td>
		</tr>
	</tbody>
</table>

<table border="0" width="100%">
	<tr>
		<td>
	<?php
			$t1=0;
			$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																				 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
			$result10 = mysqli_query($link,$sql10);
			while($row10=mysqli_fetch_array($result10)){
				$t2=$t1+1;
		?>
				
				
				................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
				
		<?php
				$t1++;
			}
		?>
		</td>		
	</tr>
</table>

<br style="page-break-before: always">



<!-- Section 2 End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section III. Evaluation and Qualification Criteria</h1>
<div style="font-size:18px;">1. Evaluation Criteria (ITB 35.3 (d)</div>
<p style="text-align:justify;">The Purchaser&#39;s evaluation of a bid may take into account, in addition to the Bid Price quoted in accordance with ITB Clause 14, one or more of the following factors as specified in ITB Sub Clause 35.3(d) and in BDS referring to ITB 35.3(d), using the following criteria and methodologies.</p>
<div>(a) Delivery schedule</div>
<br>
<div>Option 1</div>

<p style="text-align:justify;">The Goods specified in the List of Goods are required to be delivered within the acceptable time range (after the earliest and before the final date, both dates inclusive) specified in Section VI, Delivery Schedule. No credit will be given to deliveries before the earliest date, and bids offering delivery after the final date shall be treated as non responsive.</p>

<p style="text-align:justify;">(b) Deviation in payment schedule.</p>

<p style="text-align:justify;">(c) Bidders shall state their bid price for the payment schedule outlined in the Contract Data. Bids shall be evaluated on the basis of this base price. Bidders are, however, permitted to state an alternative payment schedule and indicate the reduction in bid price they wish to offer for such alternative payment schedule. The Purchaser may consider the alternative payment schedule and the reduced bid price offered by the Bidder selected on the basis of the base price for the payment schedule outlined in the Contract Data.</p>

<p style="text-align:justify;">(d)	Cost of major replacement components, mandatory spare parts, and service.</p>

<p style="text-align:justify;">The list of items and quantities of major assemblies, components, and selected spare parts, likely to be required during the initial period of operation specified in the BDS Sub-Clause 17.3, is in the List of Goods. An adjustment equal to the total cost of these items, at the unit prices quoted in each bid, shall be added to the bid price, for evaluation purposes only.</p>

<p style="text-align:justify;">e)	Specific additional criteria</p>

<p style="text-align:justify;">Other specific additional criteria to be considered in the evaluation, and the evaluation method shall be detailed in BDS Sub-Clause 35.3(d)</p>

<div style="font-size:18px;">2. Evaluation Criteria (ITB 35.4)</div>
<div>i.   Commercial Qualification </div>
<div>ii.  Technical Qualifications</div>
<div>iii. Price Qualification </div>
<div>iv.  Manufacture Authorization </div>
<div>v.	  Comprehensive Warranty</div>
<br>
<div style="font-size:18px;">3. Multiple Contracts (ITB 35.5)</div>

<p style="text-align:justify;">The Purchaser shall award multiple contracts to the Bidder that offers the lowest evaluated combination of bids (one contract per bid) and meets the post-qualification criteria (this Section III, Sub-Section ITB 37.2 Post-Qualification Requirements)</p>
<div>The Purchaser shall:</div>
<div>Evaluate the bids for lot No 01 separately to award the contract.</div>
<br>

<div style="font-size:18px;">3. Post qualification Requirements (ITB 37.2)</div>
<p style="text-align:justify;">After determining the lowest-evaluated bid in accordance with ITB Sub-Clause 36.1, the Purchaser shall carry out the post qualification of the Bidder in accordance with ITB Clause 37, using only the requirements specified. </p>

<div>(a) Financial Capability</div>
<p style="text-align:justify;">The Bidder shall furnish documentary evidence that it meets the following financial requirement(s): </p>
<p  style="text-align:justify;">1.<?php echo $a66; ?></p>

<div>(b) Experience and Technical Capacity</div>
<p  style="text-align:justify; font-weight:bold;">The Bidder shall furnish documentary evidence to demonstrate that it meets the following experience requirement(s):</p>

<?php
	for($i1=1;$i1<=$a49;$i1++){
		$sql2="SELECT * FROM ncbsec03_details WHERE project_key='$_GET[p]' AND lot_no='$i1'";
		$result2 = mysqli_query($link,$sql2);
		if(mysqli_num_rows($result2)==0){
?>
			<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
				<tbody>
					<tr>
						<td>
							<div align="center" style="font-size:22px; font-weight:bold">...............</div>
							<div align="center" style="font-size:22px; font-weight:bold">[ LOT NO <?php echo $i1;?> ]</div>
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
					</tr>
				</tbody>
			</table>
<?php
		}
		else{
			while($row2=mysqli_fetch_array($result2)){	
?>
			<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
				<tbody>
					<tr>
						<td>
							<div align="center" style="font-size:22px; font-weight:bold"><?php echo $row2['heading_lots']; ?></div>
						</td>
					</tr>
					<tr>
						<td>
							<p style="text-align:justify;"><?php echo $row2['expreance_yer']; ?></p>
						</td>
					</tr>
					<tr>
						<td>
							<p style="text-align:justify;"><?php echo $row2['expireance_handle']; ?></p>
						</td>
					</tr>
					<tr>
						<td>
							<p style="text-align:justify;"><?php echo $row2['tecnical_support']; ?></p>
						</td>
					</tr>
					<tr>
						<td>
							<p style="text-align:justify;"><?php echo $row2['manufacture_auth']; ?></p>
						</td>
					</tr>
					<tr>
						<td>
							<p style="text-align:justify;"><?php echo $row2['comp_warranty']; ?></p>
						</td>
					</tr>
				</tbody>
			</table>
			<br>
<?php
			}
		}
?>
<?php
	}
?>

<br>
<br>
<br>
<br>
<br>
<br>
<table border="0" width="100%">
	<tr>
		<td>
	<?php
			$t1=0;
			$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																				 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
			$result10 = mysqli_query($link,$sql10);
			while($row10=mysqli_fetch_array($result10)){
				$t2=$t1+1;
		?>
				
				
				................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
				
		<?php
				$t1++;
			}
		?>
		</td>		
	</tr>
</table>

<p>A.	The Bidder shall furnish documentary evidence to demonstrate that the Goods it offers meet the following usage requirement: </p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a.	ISO Certificate or any relevant Certificates for above mentioned products</p>
<br style="page-break-before: always">

<!-- Section 3 End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section IV. Bidding Forms</h1>
<div style="font-size:20px;">Bid Submission Form </div>
<p style="text-align:justify;">[The Bidder shall fill in this Form in accordance with the instructions indicated No alterations to its format shall be permitted and no substitutions shall be accepted.]</p>
<p style="text-align:justify;">Date: ...............................................</p>
<p style="text-align:justify;">No.: ................................................</p>
<p style="text-align:justify;">To: University of Colombo School of Computing</p>

<p style="text-align:justify;">We, the undersigned, declare that:</p>
<p style="text-align:justify;">&nbsp;&nbsp;(a)	We have examined and have no reservations to the Bidding Documents, including Addenda No.: </p>

<p style="text-align:justify;">We offer to supply in conformity with the Bidding Documents and in accordance with the Delivery Schedules specified in the Schedule of Requirements the following Goods and Related Services </p>
<p style="text-align:justify;"><?php echo $a100;?> (Tender No : <?php echo $projid;?>)</p>
	
	<?php
		for($i2=1;$i2<=$a49;$i2++){
		
	?>
	<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
		<thead>
			<tr>
				<th width="15%" style="font-weight:bold">S No</th>
				<th width="55%" style="font-weight:bold">Item</th>
				<th width="15%" style="font-weight:bold">Total Price <br>(Without VAT) In<br> figures (Rs)</th>
				<th width="15%" style="font-weight:bold">Total Price (With VAT) <br>in figures  (Rs) </th>
			</tr>
		</thead>
		<tbody>
			<?php
			$p1=0;
			$sql3="SELECT * FROM ncbsec45_initial_item_details WHERE project_key='$_GET[p]' AND lot_no='$i2' AND status=0";
			$result3 = mysqli_query($link,$sql3);
			while($row3=mysqli_fetch_array($result3)){	
				$p1++;
			?>
				<tr>
					<td style="font-weight:bold;font-size:18px;" align="center"><?php echo $p1; ?></td>
					<td> <?php echo $row3['item_nme']." ".$row3['qty']; ?></td>
					<td align="right"></td>
					<td align="right"></td>
				
				</tr>
			<?php
			}
			?>
			
			<tr>
				<td colspan="4">
					<?php
					$b1=null;
					$b2=null;
					$sql4="SELECT * FROM ncbsec03_details WHERE project_key='$_GET[p]' AND lot_no='$i2'";
					$result4 = mysqli_query($link,$sql4);
					while($row4=mysqli_fetch_array($result4)){
						$b1=$row4['sec4_discount1'];
						$b2=$row4['sec4_discount2'];
					}						
					?>
					<p style="text-align:justify;">(b)	The total price of our Bid without VAT, including any discounts offered is: </p>
					<p style="text-align:justify;">..........................................................................................................................................................
					..........................................................................................................................................................</p>
					
					<p style="text-align:justify;">(c)	The total price of our Bid including VAT, and any discounts offered is:  </p>
					<p style="text-align:justify;">..........................................................................................................................................................
					..........................................................................................................................................................</p>
					</p>
				</td>
			</tr>
		</tbody>
	</table>
	<?php
			
		}
	?>
<p style="text-align:justify;">(h)	Our bid shall be valid for the period of time specified in ITB Sub-Clause 18.1, from the date fixed for the bid submission deadline in accordance with ITB Sub-Clause 23.1, and it shall remain binding upon us and may be accepted at any time before the expiration of that period;</p>
<p style="text-align:justify;">(i)	If our bid is accepted, we commit to obtain a performance security in accordance with ITB Clause 43 and CC Clause 17 for the due performance of the Contract;</p>
<p style="text-align:justify;">(j)	We have no conflict of interest in accordance with ITB Sub-Clause 4.3;</p>
<p style="text-align:justify;">(h) Our firm, its affiliates or subsidiaries—including any subcontractors or suppliers for any part of the contract—has not been declared blacklisted by the National Procurement Agency;</p>
<p style="text-align:justify;">(k) We understand that this bid, together with your written acceptance thereof included in your notification of award, shall constitute a binding contract between us, until a formal contract is prepared and executed.</p>
<p style="text-align:justify;">(l) We understand that you are not bound to accept the lowest evaluated bid or any other bid that you may receive.</p>

<p style="text-align:justify;">Signed: </p>

<p style="text-align:justify;">In the capacity of </p>

<p style="text-align:justify;">Duly authorized to sign the bid for and on behalf of:  </p>
<p style="text-align:justify;">Dated on _______________________________day of _________________, _______ </p>
<p style="text-align:justify;">Company Seal</p>
<br>
<br>
<br>
<table border="0" width="100%">
	<tr>
		<td>
	<?php
			$t1=0;
			$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																				 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
			$result10 = mysqli_query($link,$sql10);
			while($row10=mysqli_fetch_array($result10)){
				$t2=$t1+1;
		?>
				
				
				................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
				
		<?php
				$t1++;
			}
		?>
		</td>		
	</tr>
</table>


<br style="page-break-before: always">
<!-- Section 4 End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section V Price Schedule </h1>
	<?php
		for($i3=1;$i3<=$a49;$i3++){
	?>
		
		<div style="font-weight:bold;">Price Schedule</div>
		<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
			<thead>
				<tr>
					<th width="10%" style="font-weight:bold">S No</th>
					<th width="50%" style="font-weight:bold">Item</th>
					<th width="10%" style="font-weight:bold">Quantity</th>
					<th width="10%" style="font-weight:bold">Unit Price  <br>(Without<br> VAT)In <br> figures(Rs.) </th>
					<th width="10%" style="font-weight:bold">Total Price <br>(Without VAT) In<br> figures(Rs.)</th>
					<th width="10%" style="font-weight:bold">Total Price (with<br> VAT) In figures(Rs.)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$totpricewithoutvat_sec5=0;
				$totpricewithtvat_sec5=0;
				$p2=0;
				$sql5="SELECT * FROM ncbsec45_initial_item_details WHERE project_key='$_GET[p]' AND lot_no='$i3' AND status=0";
				$result5 = mysqli_query($link,$sql5);
				while($row5=mysqli_fetch_array($result5)){	
					$p2++;
				?>
					<tr>
						<td style="font-weight:bold;font-size:18px;" align="center"><?php echo $p2; ?></td>
						<td><?php echo $row5['item_nme']; ?></td>
						<td><?php echo $row5['qty']; ?></td>
						<td align="right"></td>
						<td align="right"></td>
						<td align="right"></td>
					</tr>
				<?php
				}
				?>
				<tr>
						<td colspan="4" align="center" style="font-weight:bold">Grand Total (Rs)</td>
						<td align="right" style="font-weight:bold"></td>
						<td align="right" style="font-weight:bold"></td>
				</tr>
			</tbody>
		</table>
		
		<p style="text-align:justify;">Total Price Without VAT(In Figures -Rs) : </p>
		<p style="text-align:justify;">..........................................................................................................................................................
		............................................................................................................................................................</p>
		<p style="text-align:justify;">Total Price Without VAT(In Figures -Rs) : </p>
		<p style="text-align:justify;">..........................................................................................................................................................
		............................................................................................................................................................</p>
		<p style="text-align:justify;">Total Price Without  VAT(In Words - SLR) :</p>
		<p style="text-align:justify;">..........................................................................................................................................................
		............................................................................................................................................................</p>
			
		<p style="text-align:justify;">Vat Registration No  (Please attached  VAT Reg: Certificate) : .................................................................</p>
		
		
		<p style="text-align:justify;">Total Price With VAT :</p>
		<p style="text-align:justify;">..........................................................................................................................................................
		............................................................................................................................................................</p>
		<p style="text-align:justify;">Total Price With VAT (In Words - SLR) :</p>
		<p style="text-align:justify;">..........................................................................................................................................................
		............................................................................................................................................................</p>
		
		<p style="text-align:justify;">Name of the Authorized Person :........................................................................................................</p>
		<p  style="text-align:justify;">Signature of the Authorized Person : _______________________________________________</p>
		
		<div>.......................... &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;...................................</div>
		<div>&nbsp;&nbsp; Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Company Seal</div>
		
		<br>
		<br>
		<br>
		<table border="0" width="100%">
			<tr>
				<td>
			<?php
					$t1=0;
					$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																						 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
					$result10 = mysqli_query($link,$sql10);
					while($row10=mysqli_fetch_array($result10)){
						$t2=$t1+1;
				?>
						
						
						................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
						
				<?php
						$t1++;
					}
				?>
				</td>		
			</tr>
		</table>
	<?php
		}
	?>
<!-- Section 5 price list End -->	
	<br style="page-break-before: always">
	<?php
		for($i4=1;$i4<=$a49;$i4++){
			
	?>
	<div style="font-size:20px;font-weight:bold;">Bid Guarantee</div>
	<br>
	<div style="font-size:16px;font-weight:bold;"><i>FORM OF BID SECURITY</i></div>
	<p style="text-align:justify;">...............................................................................................................................................</p>
	
	<div>[Insert issuing agency&#39;s name and address of issuing branch or office]</div>
	
	<div style="font-weight:bold;">Beneficiary: Director, University of Colombo School of Computing at 35, Reid Avenue, Colombo 07.</div>
	
	<div style="font-weight:bold;">Date: ................... [Insert (by issuing agency) date]</div>
	
	<p style="text-align:justify;"><b>BID GUARANTEE NO.: ...................................</b> [Insert (by issuing agency) number] 
		We have been informed that ................................................ [Insert (by issuing agency) name of the bidder]
		(Hereinafter called &quot;the Bidder&quot;) has submitted to you its bid dated .......................... [Insert (by issuing agency) date]
		(Hereinafter called &quot;the Bid&quot;) for execution of the contract for ....................................... (Contract No: ..........................) 
		under Invitation for Bids No.  .............................. (&quot;The IFB&quot;).</p>
	
	<p style="text-align:justify;">Furthermore, we understand that, according to your conditions, Bids must be supported by a Bid Guarantee.</p>
	
	<p style="text-align:justify;">At the request of the Bidder, we ....................................................................... [Insert name of issuing agency] hereby irrevocably undertake to pay you any sum or sums not exceeding in 
				total an amount of ................................................................................................................................................................................................................. [Insert amount in words] 
				...................................... [insert amount in figures] 
				upon receipt by us of your first demand in writing accompanied by a written statement stating that the bidder is in breach of its obligation(s) under the bid conditions, because the Bidder:
	</p>
	
	<div>&#9;(a)	has withdrawn its Bid during the period of bid validity specified; or</div><br>
	<div>&#9;(b)	does not accept the correction of errors in accordance with the Instructions to Bidders &#9;(hereinafter &quot;the  ITB&quot;); or</div><br>
	<div>&#9;(c)	having been notified of the acceptance of its Bid by the Employer during the period of &#9;bid validity, (i) fails to refuses to execute the Contract Form, if required, or (ii) fails &#9;to refuses to furnish a Performance Security, in accordance with the ITB.</div><br>
	
	<p style="text-align:justify;">This guarantee shall expire: (a) if the Bidder is the successful bidder, upon our receipt of copies of the Contract signed by the Bidder and of the Performance Security issued to you by the Bidder; or (b) if the Bidder is not the successful bidder, upon the earlier of (i) the successful bidder furnishing the performance security, otherwise it will remain in force up to ..................................... </p>
	<p style="text-align:justify;">Consequently, any demand for payment under this Guarantee must be received by us at this office on or before that date.</p>
	<br>
	<br>
	<div align="center" style="font-weight:bold">...............................................................................................................</div>
	<div align="center" style="font-weight:bold">[Signature of authorized representative(s)]</div>
	<br>
	<br>
	<br>
	<br>
	<table border="0" width="100%">
		<tr>
			<td>
		<?php
				$t1=0;
				$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																					 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
				$result10 = mysqli_query($link,$sql10);
				while($row10=mysqli_fetch_array($result10)){
					$t2=$t1+1;
			?>
					
					
					................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
					
			<?php
					$t1++;
				}
			?>
			</td>		
		</tr>
	</table>
	<?php
		}
	?>
	<!-- Section 5 bid guarantee End -->	
	<br style="page-break-before: always">
	
	<h2><div style="font-size:22px;font-weight:bold;">Manufacturer&#39;s Authorization</div></h2>
	
	<p style="text-align:justify;">[The Bidder shall require the Manufacturer to fill in this Form in accordance with the instructions indicated. This letter of authorization should be on the letterhead of the Manufacturer and should be signed by a person with the proper authority to sign documents that are binding on the Manufacturer. The Bidder shall include it in its bid, if so indicated in the BDS.]</p>
	<div>Date :...................................</div><br>
	<div>No : ...............................................</div><br>
	<div>To: Director, University Of Colombo School of Computing.</div><br>
	<div>WHEREAS</div><br>
	<p style="text-align:justify;">We [insert complete name of Manufacturer], 
	who are official manufacturers of <?php echo $a72; ?> [insert type of goods manufactured], 
	having factories at  <?php echo $a73; ?> [insert full address of Manufacturer&#39;s factories], 
	do hereby authorize  <?php echo $a74; ?>[insert complete name of Bidder] to submit a bid the purpose of which is to provide the following Goods, 
	manufactured by us <?php echo $a78; ?>[insert name and or brief description of the Goods], and to subsequently negotiate and sign the Contract.</p>
	
	<p style="text-align:justify;">We hereby extend our full guarantee and warranty in accordance with Clause 27 of the Conditions of Contract, with respect to the Goods offered by the above firm.</p>
	<div>Signed:: [insert signature(s) of authorized representative(s) of the Manufacturer]</div><br><br><br>
	<div>Name: [insert complete name(s) of authorized representative(s) of the Manufacturer]</div>
	
	<p style="text-align:justify;">Title :[insert title]</p>
	
	<p style="text-align:justify;">Duly authorized to sign this Authorization on behalf of :  <?php echo $a74; ?></p>
	<p style="text-align:justify;">Dated on ______________day of __________________, ____________</p>
	
	
	<br style="page-break-before: always">

	<!-- Section 5 Manufacturers Authorization End -->
	
	
<h2><div style="font-size:20px"> Performance Security</div></h2>
<div>[The issuing agency, as requested by the successful Bidder, shall fill in this form in accordance with the instructions indicated] ...................................................................................................................................................................................................................................................................................................................&nbsp;&nbsp;&nbsp; 
<div style="text-align:justify;">Beneficiary: .............................................................................................[Name and Address of Employer]</div>
<p style="text-align:justify;">Date: ........................</p>

<p style="text-align:justify;">PERFORMANCE GUARANTEE No.: ......................................</p>

<p style="text-align:justify;">We have been informed that ................................ (hereinafter called &quot;the Supplier&quot;) has 
entered into Contract No. ........................... dated ..............................
with you, for the .......................Supply of ................................................. (hereinafter called &quot;the Contract&quot;). </p>

<p style="text-align:justify;">Furthermore, we understand that, according to the conditions of the Contract, a performance guarantee is required. 
At the request of the Supplier, we .............................................................. [name of Agency] hereby irrevocably undertake to pay you any sum or sums not exceeding in 
total an amount of Rs....................................... [amount in figures] (.............................................................................................................................................................................................................................)[amount in words], 
such sum being payable in the types and proportions of currencies in which the Contract Price is payable, upon receipt by us of your first demand in writing accompanied by a written statement stating that the Contractor is in breach of its obligation(s) under the Contract, without your needing to prove or to show grounds for your demand or the sum specified therein. This guarantee shall expire, 
no later than the ............. day of ........................................, ..............
[insert date, 28 days beyond the scheduled completion date including the warranty period] and any demand for payment under it must be received by us at this office on or before that date. </p>
<br style="page-break-before: always">
<!-- Section 8 End -->

	<h1 align="left" style="font-size:20px;font-weight:bold;">Letter of Authorization to Sign the Bid</h1>
	<br>
	<br>
	<div>Date:</div>
	<br>
	<div>Chairman  - DPC</div>
	<div>University of Colombo School of Computing</div>
	<div>No 35 Reid Avenue Colombo 00700.</div>
	<br>
	<div>Dear Sir</div>
	<br>
	<p style="text-align:justify; font-weight:bold;"><?php echo $a100; ?></p>

	<p style="text-align:justify; ">This is to authorize that Mr/ Miss............................................, bearing National Identity card No:....................................... Whose specimen signature is certified below, to sign the documents pertaining to the above bid on behalf of (Name of the Organization).</p>
	<div>Specimen signature of Authorizee: ..........................................</div>
	<br>
	<br>
	<br>

	<div>Designation of the Authorizer :  ..........................................</div>
	<br>
	<br>
	<br>
	<br>
	<div>Company Seal :   ..........................................</div>
	<div>(COMPANY DIRECTOR/S SHOULD BE AUTHORIZED)</div>

	<br style="page-break-before: always">
	
	<h1>1.	LIST OF GOODS AND DELIVERY SCHEDULE</h1>
	<div style="font-size:20px;font-weight:bold;">1.	SUPPLY ,DELIVERY, INSTALLATION, COMMISSIONING AND TESTING COMPLETION SCHEDULE </div>
	<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
		<thead>
			<tr>
				<th width="10%">Serial No.</th>
				<th width="40%">Description of Goods.</th>
				<th width="40%">Completion Date</th>
				<th width="10%">Bidder Response(Yes/No)</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td align="center">01</td>
				<td><p style="text-align:justify;"><?php echo $a100; ?></p>
					<?php
						for($i4=1;$i4<=$a49;$i4++){
					?>
						<div><?php echo $i4?></div>
					<?php
						}
					?>
				</td>
				<td><p style="text-align:justify;">Within 08-10 Weeks after issuing the Letter of Acceptance</p>
					<ul>
					  <li><p style="text-align:justify;">If exceeds the delivery period 08-10 weeks, Late delivery charges 0.5% per week from the contract sum  of each lot will be deducted. 
						The maximum amount of Late Delivery    charges shall be 10% of the contract sum from each lot.</p></li>
					</ul> 
				</td>
				<td align="center"></td>
			</tr>
		</tbody>
	</table>
	
	<p style="text-align:justify;">Name of the Authorized Person  :..........................................................................................
	
	<p style="text-align:justify;">Signature of the Authorized Person : .....................................................................................</p><br>
	<div>Date: <?php echo $cur_dte;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; .................................................</div>
	<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Company Seal</div>
			<br>
		<br>
		<table border="0" width="100%">
			<tr>
				<td>
			<?php
					$t1=0;
					$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																						 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
					$result10 = mysqli_query($link,$sql10);
					while($row10=mysqli_fetch_array($result10)){
						$t2=$t1+1;
				?>
						
						
						................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
						
				<?php
						$t1++;
					}
				?>
				</td>		
			</tr>
		</table>
		
	
	<?php
		for($i5=1;$i5<=$a49;$i5++){
	?>
		
			<br style="page-break-before: always">
			
			<?php
				$sql8="SELECT * FROM ncbsec45_initial_item_details WHERE project_key='$_GET[p]' AND lot_no='$i5' AND status=0";
				$result8 = mysqli_query($link,$sql8);
				while($row8=mysqli_fetch_array($result8)){
			?>
					<div style="font-weight:bold;font-size:19px;"><u>SPECIFICATION FOR <?php echo strtoupper($row8['item_nme'])." - ".$row8['qty'] ?>NOS </u></div>
					<br>
					
					<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
						<thead>
							<tr>
								<th width="30%" style="font-weight:bold">Specification</th>
								<th width="60%" style="font-weight:bold">Minimum Requirement</th>
								<th width="10%" style="font-weight:bold">Bidders Response <br>(Yes/No)</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$sql9="SELECT * FROM ncbsec45_itemspec_details WHERE project_key='$_GET[p]' AND lot_no='$i5' AND ncbsec45_item_key='$row8[ncbsec45_ini_item_key]' AND status=0";
							$result9 = mysqli_query($link,$sql9);
							while($row9=mysqli_fetch_array($result9)){
							?>
							<tr>
								<td width="30%" style="font-weight:bold"><?php echo $row9['specification_detail']; ?></td>
								<td width="55%" > <?php echo $row9['requirement']; ?></td>
								<td width="15%" align="center"></td>
							</tr>
							<?php
							}
							?>
							<tr>
								<td colspan="2" style="font-size:11px;font-weight:bold">Unit Price Without VAT (Rs)<br><br></td>
								<td width="15%" style="font-size:11px;">..............................................................................</td>
							</tr>
							<tr>
								<td colspan="2" style="font-size:11px;font-weight:bold">Total  Price Without  VAT (Rs)<br><br></td>
								<td width="15%" style="font-size:11px;">..............................................................................</td>
							</tr>
							<tr>
								<td colspan="2" style="font-size:11px;font-weight:bold">VAT Amount (Rs)<br><br></td>
								<td width="15%" style="font-size:11px;">..............................................................................</td>
							</tr>
							<tr>
								<td colspan="2" style="font-size:11px;font-weight:bold">Total Price With VAT (Rs)<br><br></td>
								<td width="15%" style="font-size:11px;">..............................................................................</td>
							</tr>
						</tbody>
						
					</table>
					<br>
					<div>Name of the Authorized Person  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:	......................................................................................</div>
					<br>
					<div>Signature of the Authorized Person   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:	.......................................................................................</div>
					<br>
					<br>
					<div>Date: <?php echo $cur_dte;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; .................................................</div>
					<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Company Seal</div>
					<br>
					<br>
					<br>
					<br>
					<br>
					<table border="0" width="100%">
						<tr>
							<td>
						<?php
								$t1=0;
								$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																									 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
								$result10 = mysqli_query($link,$sql10);
								while($row10=mysqli_fetch_array($result10)){
									$t2=$t1+1;
							?>
									
									
									................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
									
							<?php
									$t1++;
								}
							?>
							</td>		
						</tr>
					</table>
			<?php
				}
			?>
		<br style="page-break-before: always">
	<?php
		} 
	?>
	<!-- Section 5  End -->
<h1 align="left" style="font-size:20px;font-weight:bold;">Section VI. Conditions of Contract</h1>
<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
	<tbody>
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">1. Definitions</td>
			<td width="75%">
				<p style="text-align:justify;">1.1 The following words and expressions shall have the meanings hereby assigned to them:</p>
				<p style="text-align:justify;">(a)	&quot;Contract&quot; means the Contract Agreement entered into between the Purchaser and the Supplier, together with the Contract Documents referred to therein, including all attachments, appendices, and all documents incorporated by reference therein.</p>
				<p style="text-align:justify;">(b) &quot;Contract Documents&quot; means the documents listed in the Contract Agreement, including any amendments thereto.</p>
				<p style="text-align:justify;">(c) &quot;Contract Price&quot; means the price payable to the Supplier as specified in the Contract Agreement, subject to such additions and adjustments thereto or deductions there from, as may be made pursuant to the Contract.</p>
				<p style="text-align:justify;">(d)	&quot;Day&quot; means calendar day.</p>
				<p style="text-align:justify;">(e) &quot;Completion&quot; means the fulfillment of the supply of Goods to the destination specified and completion of the Related Services by the Supplier in accordance with the terms and conditions set forth in the Contract.</p>
				<p style="text-align:justify;">(f) &quot;CC&quot; means the Conditions of Contract.</p>
				<p style="text-align:justify;">(g) &quot;Goods&quot; means all of the commodities, raw material, machinery and equipment, and/or other materials that the Supplier is required to supply to the Purchaser under the Contract.</p>
				<p style="text-align:justify;">(h) &quot;Purchaser&quot; means the entity purchasing the Goods and Related Services, as specified in the Contract Data.</p>
				<p style="text-align:justify;">(i) &quot;Related Services&quot; means the services incidental to the supply of the goods, such as insurance, installation, training and initial maintenance and other such obligations of the Supplier under the Contract.</p>
				<p style="text-align:justify;">(j) &quot;Subcontractor&quot; means any natural person, private or government entity, or a combination of the above, to whom any part of the Goods to be supplied or execution of any part of the Related Services is subcontracted by the Supplier.</p>
				<p style="text-align:justify;">(k) &quot;Supplier&quot; means the natural person, private or government entity, or a combination of the above, whose bid to perform the Contract has been accepted by the Purchaser and is named as such in the Contract Agreement.</p>
				<p style="text-align:justify;">(l) &quot;The Project Site,&quot; where applicable, means the place named in the Contract Data.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">2. Contract Documents</td>
			<td width="75%"><p style="text-align:justify;">2.1 Subject to the order of precedence set forth in the Contract Agreement, all documents forming the Contract (and all parts thereof) are intended to be correlative, complementary, and mutually explanatory. The Contract Agreement shall be read as a whole.</p></td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">3. Fraud and Corruption</td>
			<td width="75%">
				<p style="text-align:justify;">3.1 The Government of Sri Lanka requires the Purchaser as well as bidders, suppliers, contractors, and consultants to observe the highest standard of ethics during the procurement and execution of such contracts. In pursuit of this policy:</p>
				<p style="text-align:justify;">(i) &quot;corrupt practice&quot; means offering, giving, receiving, or soliciting, directly or indirectly, of anything of value to influence the action of a public official in the procurement process or in contract execution;</p>
				<p style="text-align:justify;">(ii) &quot;fraudulent practice&quot; means a misrepresentation or omission of facts in order to influence a procurement process or the execution of a contract;</p>
				<p style="text-align:justify;">(iii) &quot;collusive practice&quot; means a scheme or arrangement between two or more bidders, with or without the knowledge of the Purchaser to establish bid prices at artificial, noncompetitive levels; and</p>
				<p style="text-align:justify;">(iv) &quot;coercive practice&quot; means harming or threatening to harm, directly or indirectly, persons or their property to influence their participation in the procurement process or affect the execution of a coract.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">4. Interpretation</td>
			<td width="75%">
				<p style="text-align:justify;">4.1 If the context so requires it, singular means plural and vice versa.</p>
				<p style="text-align:justify;">4.2 Entire Agreement</p>
				<p style="text-align:justify;">The Contract constitutes the entire agreement between the Purchaser and the Supplier and supersedes all communications, negotiations and agreements (whether written or oral) of the parties with respect thereto made prior to the date of Contract.</p>
				<p style="text-align:justify;">4.3 Amendment</p>
				<p style="text-align:justify;">No amendment or other variation of the Contract shall be valid unless it is in writing, is dated, expressly refers to the Contract, and is signed by a duly authorized representative of each party thereto.</p>
				<p style="text-align:justify;">4.4 Severability If any provision or condition of the Contract is prohibited or rendered invalid or unenforceable, such prohibition, invalidity or unenforceability shall not affect the validity or enforceability of any other provisions and conditions of the Contract.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">5. Language</td>
			<td width="75%">
				<p style="text-align:justify;">5.1 The Contract as well as all correspondence and documents relating to the Contract exchanged by the Supplier and the Purchaser, shall be written in English language. Supporting documents and printed literature that are part of the Contract may be in another language provided they are accompanied by an accurate translation of the relevant passages in the language specified, in which case, for purposes of interpretation of the Contract, this translation shall govern.</p>
				<p style="text-align:justify;">5.2 The Supplier shall bear all costs of translation to the governing language and all risks of the accuracy of such translation, for documents provided by the Supplier.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">6. Joint Venture, Consortium or Association</td>
			<td width="75%">
				<p style="text-align:justify;">6.1 If the Supplier is a joint venture, consortium, or association, all of the parties shall be jointly and severally liable to the Purchaser for the fulfillment of the provisions of the Contract and  hall designate one party to act as a leader with authority to bind the joint venture, consortium, or association. The composition or the constitution of the joint venture, consortium, or association shall not be altered without the prior consent of the Purchaser.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">7. Eligibility</td>
			<td width="75%">
				<p style="text-align:justify;">7.1 All goods supplied under this contract shall be complied with applicable standards stipulated by the Sri Lanka Standards Institute. In the absence of such standards, the Goods supplied shall be complied to other internationally accepted standards, such as British Standards.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">8. Notices</td>
			<td width="75%">
				<p style="text-align:justify;">8.1 Any notice given by one party to the other pursuant to the Contract shall be in writing to the address specified in the Contract Data. The term &quot;in writing&quot; means communicated in written form with proof of receipt.</p>
				<p style="text-align:justify;">8.2 A notice shall be effective when delivered or on the notice&#39;s effective date, whichever is later.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">9. Governing Law</td>
			<td width="75%">
				<p style="text-align:justify;">9.1 The Contract shall be governed by and interpreted in accordance with the laws of the Democratic Socialist Republic of Sri Lanka.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">10. Settlement of Disputes</td>
			<td width="75%">
				<p style="text-align:justify;">10.1 The Purchaser and the Supplier shall make every effort to resolve amicably by direct informal negotiation any disagreement or dispute arising between them under or in connection with the Contract.</p>
				<p style="text-align:justify;">10.2 If, after twenty-eight (28) days, the parties have failed to resolve their dispute or difference by such mutual consultation, then either the Purchaser or the Supplier may give notice to the other party of its intention to commence arbitration, as hereinafter provided, as to the matter in dispute, and no arbitration in respect of this matter may be commenced unless such notice is given. Any dispute or difference in respect of which a notice of intention to commence arbitration has been given in accordance with this Clause shall be finally settled by arbitration. Arbitration may be commenced prior to or after delivery of the Goods under the Contract. Arbitration proceedings shall be conducted in accordance with the Arbitration Act No:11 of 1995.</p>
				<p style="text-align:justify;">10.3 Notwithstanding any reference to arbitration herein,</p>
				<p style="text-align:justify;">(a) the parties shall continue to perform their respective obligations under the Contract unless they otherwise agree; and</p>
				<p style="text-align:justify;">(b) the Purchaser shall pay the Supplier any monies due the Supplier.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">11. Scope of Supply</td>
			<td width="75%">
				<p style="text-align:justify;">11.1 The Goods and Related Services to be supplied shall be as specified in the Schedule of Requirements.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">12. Delivery and Documents</td>
			<td width="75%">
				<p style="text-align:justify;">12.1 Subject to CC Sub-Clause 32.1, the Delivery of the Goods and Completion of the Related Services shall be in accordance with the Delivery and Completion Schedule specified in the Schedule of Requirements. Where applicable the details of shipping and other documents to be furnished by the Supplier are specified in the Contract Data.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">13. Supplier&#39;s Responsibilities</td>
			<td width="75%">
				<p style="text-align:justify;">13.1 The Supplier shall supply all the Goods and Related Services included in the Scope of Supply in accordance with CC Clause 11, and the Delivery and Completion Schedule, as per CC Clause 12.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">14. Contract Price</td>
			<td width="75%">
				<p style="text-align:justify;">14.1 Prices charged by the Supplier for the Goods supplied and the Related Services performed under the Contract shall not vary from the prices quoted by the Supplier in its bid.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">15. Terms of Payment</td>
			<td width="75%">
				<p style="text-align:justify;">15.1 The Contract Price, shall be paid as specified in the Contract Data.</p>
				<p style="text-align:justify;">15.2 The Supplier&#39;s request for payment shall be made to the Purchaser in writing, accompanied by invoices describing, as appropriate, the Goods delivered and Related Services performed, and by the documents submitted pursuant to CC Clause 12 and upon fulfillment of all other obligations stipulated in the Contract.</p>
				<p style="text-align:justify;">15.3 Payments shall be made promptly by the Purchaser, but in no case later than twenty eight (28) days after submission of an invoice or request for payment by the Supplier, and after the Purchaser has accepted it.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">16. Taxes and Duties</td>
			<td width="75%">
				<p style="text-align:justify;">16.1 The Supplier shall be entirely responsible for all taxes, duties, license fees, etc., incurred until delivery of the contracted Goods to the Purchaser.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">17. Performance Security</td>
			<td width="75%">
				<p style="text-align:justify;">17.1 If required as specified in the Contract Data, the Supplier shall, within fourteen (14) days of the notification of contract award, provide a performance security of Ten percent (10%) of the Contract Price for the performance of the Contract.</p>
				<p style="text-align:justify;">17.2 The proceeds of the Performance Security shall be payable to the Purchaser as compensation for any loss resulting from the Supplier’s failure to complete its obligations under the Contract.</p>
				<p style="text-align:justify;">17.3 As specified in the Contract Data, the Performance Security, if required, shall be in Sri Lanka Rupees and shall be in the format stipulated by the Purchaser in the Contract Data, or in another format acceptable to the Purchaser.</p>
				<p style="text-align:justify;">17.4 The Performance Security shall be discharged by the Purchaser and returned to the Supplier not later than twenty-eight (28) days following the date of Completion of the Supplier&#39;s performance obligations under the Contract, including any warranty obligations.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">18. Copyright</td>
			<td width="75%">
				<p style="text-align:justify;">18.1 The copyright in all drawings, documents, and other materials containing data and information furnished to the Purchaser by the Supplier herein shall remain vested in the Supplier, or, if they are furnished to the Purchaser directly or through the Supplier by any third party, including suppliers of materials, the copyright in such materials shall remain vested in such third party.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">19. Confidential Information</td>
			<td width="75%">
				<p style="text-align:justify;">19.1 The Purchaser and the Supplier shall keep confidential and shall not, without the written consent of the other party hereto, divulge to any third party any documents, data, or other information furnished directly or indirectly by the other party hereto in connection with the Contract, whether such information has been furnished prior to, during or following completion or termination of the Contract. Notwithstanding the above, the Supplier may furnish to its Subcontractor such documents, data, and other information it receives from the Purchaser to the extent required for the Subcontractor to perform its work under the Contract, in which event the Supplier shall obtain from such Subcontractor an undertaking of confidentiality similar to that imposed on the Supplier under CC Clause 19.</p>
				<p style="text-align:justify;">19.2 The Purchaser shall not use such documents, data, and other information received from the Supplier for any purposes unrelated to the contract. Similarly, the Supplier shall not use such documents, data, and other information received from the Purchaser for any purpose other than the performance of the Contract.</p>
				<p style="text-align:justify;">19.3 The above provisions of CC Clause 19 shall not in any way modify any undertaking of confidentiality given by either of the parties hereto prior to the date of the Contract in respect of the Supply or any part thereof.</p>
				<p style="text-align:justify;">19.4 The provisions of CC Clause 19 shall survive completion or termination, for whatever reason, of the Contract.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">20. Subcontracting</td>
			<td width="75%">
				<p style="text-align:justify;">20.1 The Supplier shall notify the Purchaser in writing of all subcontracts awarded under the Contract if not already specified in the bid. Such notification, in the original bid or later shall not relieve the Supplier from any of its obligations, duties, responsibilities, or liability under the Contract.</p>
				<p style="text-align:justify;">20.2 Subcontracts shall comply with the provisions of CC Clauses 3 and 7.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">21. Specifications and Standards</td>
			<td width="75%">
				<p style="text-align:justify;">21.1 Technical Specifications and Drawings</p>
				<p style="text-align:justify;">(a) The Goods and Related Services supplied under this Contract shall conform to the technical specifications and standards mentioned in Section V, Schedule of Requirements and, when no applicable standard is mentioned, the standard shall be equivalent or superior to the official standards whose application is appropriate to the Goods’ country of origin.</p>
				<p style="text-align:justify;">(b) The Supplier shall be entitled to disclaim responsibility for any design, data, drawing, specification or other document, or any modification thereof provided or designed by or on behalf of the Purchaser, by giving a notice of such disclaimer to the Purchaser.</p>
				<p style="text-align:justify;">(c) Wherever references are made in the Contract to codes and standards in accordance with which it shall be executed, the edition or the revised version of such codes and standards shall be those specified in the Schedule of Requirements. During Contract execution, any changes in any such codes and standards shall be applied only after approval by the Purchaser and shall be treated in accordance with CC Clause 32.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">22. Packing and Documents</td>
			<td width="75%">
				<p style="text-align:justify;">22.1 The Supplier shall pack the Goods as is required to prevent their damage or deterioration during transit to their final destination, as indicated in the Contract.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">23. Insurance</td>
			<td width="75%">
				<p style="text-align:justify;">23.1 Unless otherwise specified in the Contract Data, the Goods supplied under the Contract shall be fully insured against loss or damage incidental to manufacture or acquisition, transportation, storage, and delivery.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">24. Transportation</td>
			<td width="75%">
				<p style="text-align:justify;">24.1 Unless otherwise specified in the Contract Data, responsibility for arranging transportation of the Goods shall be a responsibility of the supplier.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">25. Inspections and Tests</td>
			<td width="75%">
				<p style="text-align:justify;">25.1 The Supplier shall at its own expense and at no cost to the Purchaser carry out all such tests and/or inspections of the Goods and Related Services as are specified in the Contract Data.</p>
				<p style="text-align:justify;">25.2 The inspections and tests may be conducted on the premises of the Supplier or its Subcontractor, at point of delivery, and/or at the Goods’ final destination, or in another place as specified in the Contract Data. Subject to CC Sub-Clause 25.3, if conducted on the premises of the Supplier or its Subcontractor, all reasonable facilities and assistance, including access to drawings and production data, shall be furnished to the inspectors at no charge to the Purchaser.</p>
				<p style="text-align:justify;">25.3 The Purchaser or its designated representative shall be entitled to attend the tests and/or inspections referred to in CC Sub-Clause 25.2, provided that the Purchaser bear all of its own costs and expenses incurred in connection with such attendance including, but not limited to, all traveling and board and lodging expenses.</p>
				<p style="text-align:justify;">25.4 Whenever the Supplier is ready to carry out any such test and inspection, it shall give a reasonable advance notice, including the place and time, to the Purchaser. The Supplier shall obtain from any relevant third party or manufacturer any necessary permission or consent to enable the Purchaser or its designated representative to attend the test and/or inspection.</p>
				<p style="text-align:justify;">25.5 The Purchaser may require the Supplier to carry out any test and/or inspection not required by the Contract but deemed necessary to verify that the characteristics and performance of the Goods comply with the technical specifications codes and standards under the Contract, provided that the Supplier’s reasonable costs and expenses incurred in the carrying out of such test and/or inspection shall be added to the Contract Price. Further, if such test and/or inspection impedes the progress of manufacturing and/or the Supplier’s performance of its other obligations under the Contract, due allowance will be made in respect of the Delivery Dates and Completion Dates and the other obligations so affected.</p>
				<p style="text-align:justify;">25.6 The Supplier shall provide the Purchaser with a report of the results of any such test and/or inspection.</p>
				<p style="text-align:justify;">25.7 The Purchaser may reject any Goods or any part thereof that fail to pass any test and/or inspection or do not conform to the specifications. The Supplier shall either rectify or replace such rejected Goods or parts thereof or make alterations necessary to meet the specifications at no cost to the Purchaser, and shall repeat the test and/or inspection, at no cost to the Purchaser, upon giving a notice pursuant to CC Sub-Clause 25.4.</p>
				<p style="text-align:justify;">25.8 The Supplier agrees that neither the execution of a test and/or inspection of the Goods or any part thereof, nor the attendance by the Purchaser or its representative, nor the issue of any report pursuant to CC Sub-Clause 25.6, shall release the Supplier from any warranties or other obligations under the Contract.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">26. Liquidated Damages</td>
			<td width="75%">
				<p style="text-align:justify;">26.1 Except as provided under CC Clause 31, if the Supplier fails to deliver any or all of the Goods by the Date(s) of delivery or perform the Related Services within the period specified in the Contract, the Purchaser may without prejudice to all its other remedies under the Contract,
					deduct from the Contract Price, as liquidated damages, a sum equivalent to the percentage specified in the Contract Data of the delivered price of the delayed Goods or unperformed Services for each week or part thereof of delay until actual delivery or performance, up to a maximum deduction of the percentage specified in those Contract Data. Once the maximum is reached, the Purchaser may terminate the Contract pursuant to CC Clause 34.
				</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">27. Warranty</td>
			<td width="75%">
				<p style="text-align:justify;">27.1 The Supplier warrants that all the Goods are new, unused, and of the most recent or current models, and that they incorporate all recent improvements in design and materials, unless provided otherwise in the Contract.</p>
				<p style="text-align:justify;">27.2 Subject to CC Sub-Clause 21.1(b), the Supplier further warrants that the Goods shall be free from defects arising from any act or omission of the Supplier or arising from design, materials, and workmanship, under normal use in the conditions prevailing in the country of final destination.</p>
				<p style="text-align:justify;">27.3 Unless otherwise specified in the Contract Data, the warranty shall remain valid for twelve (12) months after the Goods, or any portion thereof as the case may be, have been delivered to and accepted at the final destination indicated in the Contract Data.</p>
				<p style="text-align:justify;">27.4 The Purchaser shall give notice to the Supplier stating the nature of any such defects together with all available evidence thereof, promptly following the discovery thereof. The Purchaser shall afford all reasonable opportunity for the Supplier to inspect such defects.</p>
				<p style="text-align:justify;">27.5 Upon receipt of such notice, the Supplier shall, within the period specified in the Contract Data, expeditiously repair or replace the defective Goods or parts thereof, at no cost to the Purchaser.</p>
				<p style="text-align:justify;">27.6 If having been notified, the Supplier fails to remedy the defect within the period specified in the Contract Data, the Purchaser may proceed to take within a reasonable period such remedial action as may be necessary, at the Supplier’s risk and expense and without prejudice to any other rights which the Purchaser may have against the Supplier under the Contract.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">28. Patent Indemnity</td>
			<td width="75%">
				<p style="text-align:justify;">28.1 The Supplier shall, subject to the Purchaser’s compliance with CC Sub-Clause 28.2, indemnify and hold harmless the Purchaser and its employees and officers from and against any and all suits, actions or administrative proceedings, claims, demands, losses, damages, costs, and expenses of any nature, including attorney’s fees and expenses, which the Purchaser may suffer as a result of any infringement or alleged infringement of any patent, utility model, registered design, trademark, copyright, or other intellectual property right registered or otherwise existing at the date of the Contract by reason of:</p>
				<p style="text-align:justify;">(a) the installation of the Goods by the Supplier or the use of the Goods in the country where the Site is located; and</p>
				<p style="text-align:justify;">(b) the sale in any country of the products produced by the Goods. Such indemnity shall not cover any use of the Goods or any part thereof other than for the purpose indicated by or to be reasonably inferred from the Contract, neither any infringement resulting from the use of the Goods or any part thereof, or any products produced thereby in association or combination with any other equipment, plant, or materials not supplied by the Supplier, pursuant to the Contract.</p>
				<p style="text-align:justify;">28.2 If any proceedings are brought or any claim is made against the Purchaser arising out of the matters referred to in CC Sub-Clause 28.1, the Purchaser shall promptly give the Supplier a notice thereof, and the Supplier may at its own expense and in the Purchaser’s name conduct such proceedings or claim and any negotiations for the settlement of any such proceedings or claim.</p>
				<p style="text-align:justify;">28.3 If the Supplier fails to notify the Purchaser within twenty eight (28) days after receipt of such notice that it intends to conduct any such proceedings or claim, then the Purchaser shall be free to conduct the same on its own behalf.</p>
				<p style="text-align:justify;">28.4 The Purchaser shall, at the Supplier’s request, afford all available assistance to the Supplier in conducting such proceedings or claim, and shall be reimbursed by the Supplier for all reasonable expenses incurred in so doing.</p>
				<p style="text-align:justify;">28.5 The Purchaser shall indemnify and hold harmless the Supplier and its employees, officers, and Subcontractors from and against any and all suits, actions or administrative proceedings, claims, demands, losses, damages, costs, and expenses of any nature, including attorney’s fees and expenses, which the Supplier may suffer as a result of any infringement or alleged infringement of any patent, utility model, registered design, trademark, copyright, or other intellectual property right registered or otherwise existing at the date of the Contract arising out of or in connection with any design, data, drawing, specification, or other documents or materials provided or designed by or on behalf of the Purchaser.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">29. Limitation of Liability</td>
			<td width="75%">
				<p style="text-align:justify;">29.1 Except in cases of criminal negligence or willful misconduct,</p>
				<p style="text-align:justify;">(a) the Supplier shall not be liable to the Purchaser, whether in contract, tort, or otherwise, for any indirect or consequential loss or damage, loss of use, loss of production, or loss of profits or interest costs, provided that this exclusion shall not apply to any obligation of the Supplier to pay liquidated damages to the Purchaser and </p>
				<p style="text-align:justify;">(b) the aggregate liability of the Supplier to the Purchaser, whether under the Contract, in tort or otherwise, shall not exceed the total Contract Price, provided that this limitation shall not apply to the cost of repairing or replacing defective equipment, or to any obligation of the supplier to indemnify the purchaser with respect to patent infringement</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">30. Change in Laws and Regulations</td>
			<td width="75%">
				<p style="text-align:justify;">30.1 Unless otherwise specified in the Contract, if after the date of 28 days prior to date of Bid submission, any law, regulation, ordinance, order or bylaw having the force of law is enacted, promulgated, abrogated, or changed in Sri Lanka that subsequently affects the Delivery Date and/or the Contract Price, then such Delivery Date and/or Contract Price shall be correspondingly increased or decreased, to the extent that the Supplier has thereby been affected in the performance of any of its obligations under the Contract. Notwithstanding the foregoing, such additional or reduced cost shall not be separately paid or credited if the same has already been accounted for in the price adjustment provisions where applicable, in accordance with CC Clause 14.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">31. Force Majeure</td>
			<td width="75%">
				<p style="text-align:justify;">31.1 The Supplier shall not be liable for forfeiture of its Performance Security, liquidated damages, or termination for default if and to the extent that its delay in performance or other failure to perform its obligations under the Contract is the result of an event of Force Majeure.</p>
				<p style="text-align:justify;">31.2 For purposes of this Clause, &quot;Force Majeure&quot; means an event or situation beyond the control of the Supplier that is not foreseeable, is unavoidable, and its origin is not due to negligence or lack of care on the part of the Supplier. Such events may include, but not be limited to, acts of the Purchaser in its sovereign capacity, wars or revolutions, fires, floods, epidemics, quarantine restrictions, and freight embargoes.</p>
				<p style="text-align:justify;">31.3 If a Force Majeure situation arises, the Supplier shall promptly notify the Purchaser in writing of such condition and the cause thereof. Unless otherwise directed by the Purchaser in writing, the Supplier shall continue to perform its obligations under the Contract as far as is reasonably practical, and shall seek all reasonable alternative means for performance not prevented by the Force Majeure event.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">32. Change Orders and Contract Amendments</td>
			<td width="75%">
				<p style="text-align:justify;">32.1 The Purchaser may at any time order the Supplier through notice in accordance CC Clause 8, to make changes within the general scope of the Contract in any one or more of the following:</p>
				<p style="text-align:justify;">(a) drawings, designs, or specifications, where Goods to be furnished under the Contract are to be specifically manufactured for the Purchaser;</p>
				<p style="text-align:justify;">(b) the method of shipment or packing;</p>
				<p style="text-align:justify;">(c) the place of delivery; and</p>
				<p style="text-align:justify;">(d) the Related Services to be provided by the Supplier.</p>
				<p style="text-align:justify;">32.2 If any such change causes an increase or decrease in the cost of, or the time required for, the Supplier’s performance of any provisions under the Contract, an equitable adjustment shall be made in the Contract Price or in the Delivery/Completion Schedule, or both, and the Contract shall accordingly be amended. Any claims by the Supplier for adjustment under this Clause must be asserted within twenty-eight (28) days from the date of the Supplier’s receipt of the Purchaser’s change order.</p>
				<p style="text-align:justify;">32.3 Prices to be charged by the Supplier for any Related Services that might be needed but which were not included in the Contract shall be agreed upon in advance by the parties and shall not exceed the prevailing rates charged to other parties by the Supplier for similar services.</p>
				<p style="text-align:justify;">32.4 Subject to the above, no variation in or modification of the terms of the Contract shall be made except by written amendment signed by the parties.</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">33. Extensions of Time</td>
			<td width="75%">
				<p style="text-align:justify;">33.1 If at any time during performance of the Contract, the Supplier or its subcontractors should encounter conditions impeding timely delivery of the Goods or completion of Related Services pursuant to CC Clause 12, the Supplier shall promptly notify the Purchaser in writing of the delay, its likely duration, and its cause. As soon as practicable after receipt of the Supplier’s notice, the Purchaser shall evaluate the situation and may at its discretion extend the Supplier’s time for performance, in which case the extension shall be ratified by the parties by amendment of the Contract.</p>
				<p style="text-align:justify;">33.2 Except in case of Force Majeure, as provided under CC Clause 31, a delay by the Supplier in the performance of its Delivery and Completion obligations shall render the Supplier liable to the imposition of liquidated damages pursuant to CC Clause 26, unless an extension of time is agreed upon, pursuant to CC Sub-Clause 33.1</p>
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">34. Termination</td>
			<td width="75%">
				<p style="text-align:justify;">34.1 Termination for Default</p>
				<p style="text-align:justify;">(a) The Purchaser, without prejudice to any other remedy for breach of Contract, by written notice of default sent to the Supplier, may terminate the Contract in whole or in part:</p>
				<p style="text-align:justify;">(i) if the Supplier fails to deliver any or all of the Goods within the period specified in the Contract, or within any extension thereof granted by the Purchaser pursuant to CC Clause 33;</p>
				<p style="text-align:justify;">(ii) if the Supplier fails to perform any other obligation under the Contract; or</p>
				<p style="text-align:justify;">(iii) if the Supplier, in the judgment of the Purchaser has engaged in fraud and corruption, as defined in CC Clause 3, in competing for or in executing the Contract.</p>
				<p style="text-align:justify;">(b) In the event the Purchaser terminates the Contract in whole or in part, pursuant to CC Clause 34.1(a), the Purchaser may procure, upon such terms and in such manner as it deems appropriate, Goods or Related Services similar to those undelivered or not performed, and the Supplier shall be liable to the Purchaser for any additional costs for such similar Goods or Related Services. However, the Supplier shall continue performance of the Contract to the extent not terminated.</p>
				<p style="text-align:justify;">34.2 Termination for Insolvency.</p>
				<p style="text-align:justify;">(a) The Purchaser may at any time terminate the Contract by giving notice to the Supplier if the Supplier becomes bankrupt or otherwise insolvent. In such event, termination will be without compensation to the Supplier, provided that such termination will not prejudice or affect any right of action or remedy that has accrued or will accrue thereafter to the Purchaser 34.3 Termination for Convenience.</p>
				<p style="text-align:justify;">(a)	The Purchaser, by notice sent to the Supplier, may terminate the Contract, in whole or in part, at any time for its convenience. The notice of termination shall specify that termination is for the Purchaser’s convenience, the extent to which performance of the Supplier under the Contract is terminated, and the date upon which such termination becomes effective.</p>
				<p style="text-align:justify;">(b) The Goods that are complete and ready for shipment within twenty-eight (28) days after the Supplier’s receipt of notice of termination shall be accepted by the Purchaser at the Contract terms and prices. For the remaining Goods, the Purchaser may elect:</p>
				<p style="text-align:justify;">(i) to have any portion completed and delivered at the Contract terms and prices; and/or</p>
				<p style="text-align:justify;">(ii) to cancel the remainder and pay to the Supplier an agreed amount for partially completed</p>
				<p style="text-align:justify;">Goods and Related Services and for materials and parts previously procured by the Supplier.</p>
				
			</td>
		</tr>
		
		<tr>
			<td width="25%" style="font-weight:bold;" valign="top">35. Assignment</td>
			<td width="75%">
				<p style="text-align:justify;">35.1 Neither the Purchaser nor the Supplier shall assign, in whole or in part, their obligations under this Contract, except with prior written consent of the other party.</p>
			</td>
		</tr>
	</tbody>
</table>
<br style="page-break-before: always">
<!-- Section 6  End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section VII. Contract Data</h1>
<p style="text-align:justify;">The following Contract Data shall supplement and / or amend the Conditions of Contract (CC). Whenever there is a conflict, the provisions herein shall prevail over those in the CC.</p>

<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
	<tbody>
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 1.1(i)</td>
			<td width="85%">The Purchaser is: <b>University Of Colombo School of Computing</b></td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 1.1 (m) </td>
			<td width="85%">
				<div>The Project Site(s)/Final Destination(s) is/are:</div>
				<div style="font-weight:bold;">University Of Colombo School of Computing, No 35, Reid Avenue, Colombo 07. </div>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 8.1</td>
			<td width="85%">
				<p style="text-align:justify;">For notices, the Purchaser’s address shall be: <b>University Of Colombo School of Computing No 35 Reid Avenue Colombo 00700.</b></p>
				<div>Attention: <b>Mr. Viswajith Mapa</b> </div>
				<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Assistant Network Manager</b> </div>
				<br>
				<div>Address: <b>University Of Colombo School of Computing </b> </div>
				<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>No 35 Reid Avenue Colombo 00700.</b> </div>
				<br>
				<div>Telephone: 011 2 581 245/7 Ext: 8925</div>
				<br>
				<div>Facsimile number : 011 2 587 239</div>
				<br>
				<div>Electronic mail address: proc@ucsc.cmb.ac.lk</div>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 12.1</td>
			<td width="85%">
				<p style="text-align:justify;">Details of Shipping and other Documents to be furnished by the Supplier.</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 15.1</td>
			<td width="85%">
				<p style="text-align:justify;">Sample provision[Select appropriately]</p>
				<p style="text-align:justify;">CC 15.1—The method and conditions of payment to be made to the Supplier under this Contract shall be as follows:</p>
				<p style="text-align:justify;">Payment shall be made in Sri Lanka Rupees within Thirty (30) days of presentation of claim supported by a certificate from the Purchaser declaring that the Goods have been delivered and that all other contracted Services have been performed.</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 17.1</td>
			<td width="85%">
				<p style="text-align:justify;">A Performance Security shall be 10% of the Bid Value</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 25.1</td>
			<td width="85%">
				<p style="text-align:justify;">The inspections and tests shall be: done by the U C S C</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 25.2</td>
			<td width="85%">
				<p style="text-align:justify;">The Inspections and tests shall be conducted at: the U C S C</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 26.1</td>
			<td width="85%">
				<p style="text-align:justify;">The liquidated damage shall be: 0.5 % per week</p>
			</td>
		</tr>
		
		<tr>
			<td width="15%" style="font-weight:bold;" valign="top">CC 26.1</td>
			<td width="85%">
				<p style="text-align:justify;">The maximum amount of liquidated damages shall be: 10 %</p>
			</td>
		</tr>
	</tbody>
</table>
<br>
<br>


<table border="0" width="100%">
	<tr>
		<td>
	<?php
			$t1=0;
			$sql10="SELECT * FROM appoint_tec_details INNER JOIN user_master ON appoint_tec_details.user_key=user_master.user_key
																				 WHERE appoint_tec_details.project_key='$_GET[p]' AND  appoint_tec_details.status=0 AND user_master.status=0";
			$result10 = mysqli_query($link,$sql10);
			while($row10=mysqli_fetch_array($result10)){
				$t2=$t1+1;
		?>
				
				
				................<?php echo $row10['first_name']." ".$row10['last_name'];?>&nbsp;&nbsp;&nbsp;
				
		<?php
				$t1++;
			}
		?>
		</td>		
	</tr>
</table>
<br style="page-break-before: always">
<!-- Section 7  End -->

<h1 align="left" style="font-size:20px;font-weight:bold;">Section VIII. Contract Form</h1>
<div style="font-size:20px">1. CONTRACT AGREEMENT</div>
<br>
<div >THIS CONTRACT AGREEMENT is made</div>
<br>
<div>the [ insert: number ] day of [ insert: month ],[ insert: year ].</div>
<br>
<div >BETWEEN</div>
<p style="text-align:justify;">(1) [ insert complete name of Purchaser ], 
	a  [ insert description of type of legal entity, for example, an agency of the Ministry of ......... or corporation and having its principal place of business at
	[ insert address of Purchaser ] (hereinafter called &quot;the Purchaser&quot;), and </p>

<p style="text-align:justify;">(2) [ insert name of Supplier ], 
a corporation incorporated under the laws of [ insert: country of Supplier ] and having 
its principal place of business at [ insert: address of Supplier ] 
(hereinafter called &quot;the Supplier&quot;).</p>

<p style="text-align:justify;">WHEREAS the Purchaser invited bids for certain Goods and ancillary services, 
viz [insert brief description of Goods and Services] and has accepted a Bid by the Supplier for the supply of those 
Goods and Services in the sum of [insert Contract Price in words and figures, expressed in the Contract currency(ies) ] (hereinafter called &quot;the Contract Price&quot;).</p>

<br>

<div>NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:</div>

<p style="text-align:justify;">1. In this Agreement words and expressions shall have the same meanings as are respectively assigned to them in the Conditions of Contract referred to.</p>
<p style="text-align:justify;">2. The following documents shall constitute the Contract between the Purchaser and the Supplier, and each shall be read and construed as an integral part of the Contract:</p>
<p style="text-align:justify;">(a) This Contract Agreement</p>
<p style="text-align:justify;">(b) Contract Data</p>
<p style="text-align:justify;">(c) Conditions of Contract</p>
<p style="text-align:justify;">(d) Technical Requirements (including Schedule of Requirements and Technical Specifications)</p>
<p style="text-align:justify;">(e) The Supplier&#39;s Bid and original Price Schedules</p>
<p style="text-align:justify;">(f) The Purchaser&#39;s Notification of Award</p>
<p style="text-align:justify;">(g) [Add here any other document(s)]</p>
<p style="text-align:justify;">3. This Contract shall prevail over all other Contract documents. In the event of any discrepancy or inconsistency within the Contract documents, then the documents shall prevail in the order listed above.</p>
<p style="text-align:justify;">4. In consideration of the payments to be made by the Purchaser to the Supplier as hereinafter mentioned, the Supplier hereby covenants with the Purchaser to provide the Goods and Services and to remedy defects therein in conformity in all respects with the provisions of the Contract.</p>
<p style="text-align:justify;">5. The Purchaser hereby covenants to pay the Supplier in consideration of the provision of the Goods and Services and the remedying of defects therein, the Contract Price or such other sum as may become payable under the provisions of the Contract at the times and in the manner prescribed by the Contract.</p>
<p style="text-align:justify;">IN WITNESS whereof the parties hereto have caused this Agreement to be executed in accordance with the laws of Democratic Socialist Republic of Sri Lanka on the day, month and year indicated above. </p>
<p style="text-align:justify;">For and on behalf of the Purchaser</p>
<p style="text-align:justify;"></p>
<br style="page-break-before: always">
<!-- Section 8  CONTRACT AGREEMENT End -->




	<h1 align="center" style="font-size:0px;">PROCUREMENT NOTICE</h1>
	<div style="border: 1px black solid">
	<div align="center" style="font-size:16px; font-weight:bold;">PROCUREMENT NOTICE</div>
	<div align="center" style="font-size:14px;">(<?php echo $a42;  ?> FUNDS)</div>
	<div align="center"><img src="gv.png" width="8%" height="10%"></div>
	<div align="center" style="font-weight:bold;">UNIVERSITY OF COLOMBO SCHOOL OF COMPUTING (UCSC)</div>
	<br>
	<div align="center" style="font-weight:bold; font-size:14px;"><?php echo $a100; ?></div>
	<br>
	<div align="center" style="font-weight:bold; font-size:14px;"><u>(PROC NO: <?php echo $projid; ?>)</u></div>
	<p style="text-align:justify;font-size:14px; ">1.	The Chairman, Department Procurement Committee of University of Colombo School of Computing (UCSC) invites sealed bids from eligible bidders for 
	<b><?php echo $a100; ?></b>. 
	The bidders may submit  bids for separately. 
	The bids will be evaluated on separate lot basis. </p>
	
	<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
	<thead>
		<tr style="font-size:15px; font-weight:bold;">	
			<th width="20%">Procurement No</th>
			<th width="45%">Description of Goods</th>
			<th width="10%">Quantity</th>
			<th width="25%">Bid Bond Amount (Rs)</th>
		</tr>
	</thead>
	<tbody>
		<?php
		$sql7="SELECT MIN(ncbsec45_ini_item_key)AS mininiitem_key FROM ncbsec45_initial_item_details WHERE project_key='$_GET[p]' AND status=0";
		$result7 = mysqli_query($link,$sql7);
		while($row7=mysqli_fetch_array($result7)){
			$r1=$row7['mininiitem_key'];
		}
		
		$sql6="SELECT * FROM ncbsec45_initial_item_details WHERE project_key='$_GET[p]' AND status=0";
		$result6 = mysqli_query($link,$sql6);
		$allitem=mysqli_num_rows($result6);
		while($row6=mysqli_fetch_array($result6)){
			//for($i7=1;$i7<=$a49;$i7++){
		?>
			<?php
			if($r1==$row6['ncbsec45_ini_item_key']){
			?>
			<tr style="font-size:14px;">
				<td rowspan="<?php echo $allitem; ?>"><?php echo $projid; ?></td>
				<td><b><?php echo $row6['item_nme'];?></b></td>
				<td><b><?php echo $row6['qty'];?> NOS</b></td>
				<td align="center"><b><?php echo number_format($row6['bidbond_amount'],2);?></b></td>
			</tr>
			<?php
			}
			else{
			?>
			<tr style="font-size:14px;">
				<td><b>Lot <?php echo $row6['lot_no'];?></b></td>
				<td><b><?php echo $row6['item_nme'];?></b></td>
				<td><b><?php echo $row6['qty'];?> NOS</b></td>
				<td align="center"><b><?php echo number_format($row6['bidbond_amount'],2);?></b></td>
			</tr>
			<?php
			}
			?>
		<?php
		}
		?>
	</tbody>
	</table>
	
	<p style="text-align:justify;font-size:14px; ">2.	Bidding will be conducted through the National Competitive Bidding (NCB) Procedures.</p>
	<p style="text-align:justify;font-size:14px; ">3.	A complete set of bidding documents in English Language may be purchased by interested bidders on the submission of written application to the Senior Assistant Bursar - Procurements UCSC No 35 Reid Avenue Colombo 00700 and upon payment of a non-refundable fee of 
	<b>Rs.5, 000.00 </b>for each Bidding Document. The method of payment will be in cash to the Shroff Counter at the UCSC during working hours from 
	<b><?php echo date("jS F Y", strtotime($a55));?>  to <?php echo date("jS F Y", strtotime($a59));?> </b>. Bidding documents may be inspected free of charge at the Finance Division at the UCSC during working hours.</p>
	
	<p style="text-align:justify;font-size:14px; ">4.	The duly completed Sealed bids  with Duplicate, addressed to the 
	<b>&quot;Chairman DPC University of Colombo School of Computing(UCSC)&quot;</b>  should be deposited to the Tender Box at the Finance Branch 1st Floor of the UCSC No 35, Reid Avenue, Colombo 07 
	<b>on or before <?php echo $a63;?> on <?php echo date("jS F Y", strtotime($a62));?> </b>. Bids will be opened in the presence of the bidders or bidder’s representatives who choose to attend at the address below, immediately after closing of bids. Late bids will be rejected. All bids must be accompanied by a bid security for each lot as mentioned in above table, which shall be 
	valid up to <b><?php echo date("jS F Y", strtotime($a57));?></b>.</p>
	
	<div align="center" style="font-size:13px;">Director/ Chairman DPC</div>
	<div align="center" style="font-size:13px;">University of Colombo School of Computing (UCSC)</div>
	<div align="center" style="font-size:13px;">No 35 Reid Avenue Colombo 00700.</div>
	<div align="center" style="font-size:13px;">Tel: (0112) 581 245/Ex-8934  Fax: (0112) 587 239</div>
</div>
</body>
</html>

<?php
  header("Content-type: application/vnd.ms-word");
  header("Content-Disposition: attachment;Filename=003-NCB_Bidding_Document_".$projid.".doc");   
?>