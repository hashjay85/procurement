<?php 
include("includes/a_config.php");
//error_reporting(0);
?>
<?php 
include("includes/conn.php");
include("includes/sessionconfig.php");
?>


<?php
	$sql3="SELECT * FROM boq_master INNER JOIN project_master ON boq_master.projmas_key=project_master.projmas_key
						WHERE boq_master.projmas_key='$_GET[p]'";
	$result3 = mysqli_query($link,$sql3);
	while($row3=mysqli_fetch_array($result3)){	
		$p_id=$row3['project_id'];
		$p_nme=$row3['project_nme'];
			
	}

?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
	
	  <meta charset="utf-8">

  
		<script language="javascript">
			
		</script>
		
		<style type="text/css">
			.ttotal{
				font-size:16px;
				font-weight:bold;
			}
		
		</style>
  
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">


	<form name="f1" method="post" >
		<div class="form-group">
		  <label for="sel1">Select the Project ID</label>
			<select class="form-control input-sm" id="sel1" name="sele_sell">
					<?php
						if(isset($_GET['p'])){
					?>
						<option value="<?php echo $_GET['p'];?>"><?php echo $p_id." - ".$p_nme; ?></option>
					<?php
						}
						else{
							$sql1="SELECT * FROM project_master	WHERE status=0";
							$result1 = mysqli_query($link,$sql1);
							while($row1=mysqli_fetch_array($result1)){	
					?>
							 <option value="" disabled selected hidden>Please Choose.............</option>
							 <option value="<?php echo $row1['projmas_key'];?>"><?php echo $row1['project_id']." - ".$row1['project_nme'] ?></option>
					<?php
							}
						}
					?>
			</select>
		</div>
	</form>
	</br>
	</br>
	</br>
		<div class="row">
			<div class="col-md-4">
			
			</div>
			<div class="col-md-4">
				<table class="table table-striped table-bordered display" width="50%">
					<thead>
						<tr>
							<th>Boq Code</th>
							<th>Supplier</th>
							<th>Boq Value</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$n=0;
							$sql2="SELECT * FROM boq_master WHERE projmas_key='$_GET[p]' AND boq_master.status=0";
							$result2 = mysqli_query($link,$sql2);
							while($row2=mysqli_fetch_array($result2)){	
						?>
						<tr>
							<td><?php echo $row2['boq_code'];?></td>
							<?php
								$sql4="SELECT * FROM supplier_master WHERE supplierms_key='$row2[supplier_key]' AND status=0";
								$result4 = mysqli_query($link,$sql4);
								while($row4=mysqli_fetch_array($result4)){	
							?>
							<td><?php echo $row4['supplier_name'];?></td>
							<?php
								}
							?>
							<?php
								$sql3="SELECT SUM(price*qty) AS totvalues1 FROM boq_details WHERE boqmaster_key='$row2[boqmas_key]' AND status=0";
								$result3 = mysqli_query($link,$sql3);
								while($row3=mysqli_fetch_array($result3)){	
							?>
							<td align="right"><?php if($row3['totvalues1']==0){echo number_format(0,2);}else{echo number_format($row3['totvalues1'],2);}?></td>
							<?php
									$n+=$row3['totvalues1'];
								}
							?>
							
						</tr>
						<?php
							}
						?>
						
					
						<tr>
							<td class="ttotal" colspan="2">Total</td>
							<td align="right" class="ttotal"><?php echo number_format($n,2);?></td>
						<tr>
						
					</tbody>
				</table>
			</div>
			<div class="col-md-4">
			
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-4">
				<a href="home.php"><button class="btn btn-primary btn-lg">Home</button></a>						
			</div>
			<div class="col-md-4">
			
			</div>
			<div class="col-md-4">
				
			</div>
		</div>
	
<body>



<!-- Footer -->

<?php include("includes/footer.php");?>
<script type="text/javascript">
$("#f2").submit(function(event){
   loadAjax();
   event.preventDefault()
})
</script>
</body>
</html>