<?php
 ob_start();
 $cur_dte=date("Y-m-d");
	include("includes/conn.php");
	
	$sql1="SELECT * FROM direct_purches_master INNER JOIN supplier_master
								ON direct_purches_master.supplier_key=supplier_master.supplierms_key
								WHERE 
								direct_purches_master.direct_mas_key='$_GET[p]' AND direct_purches_master.status=0";
	$result1 = mysqli_query($link,$sql1);
	while($row1=mysqli_fetch_array($result1)){	
			$a1=$row1['date'];
			$a2=$row1['direct_id'];
			$a3=$row1['heading'];
			$a4=$row1['supplier_name'];
			$a5=$row1['address'];
			
	}
	
	
	
	function convertNumber($num = false)
		{
			$num = str_replace(array(',', ''), '' , trim($num));
			if(! $num) {
				return false;
			}
			$num = (int) $num;
			$words = array();
			$list1 = array('', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
				'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'
			);
			$list2 = array('', 'ten', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred');
			$list3 = array('', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'quintillion', 'sextillion', 'septillion',
				'octillion', 'nonillion', 'decillion', 'undecillion', 'duodecillion', 'tredecillion', 'quattuordecillion',
				'quindecillion', 'sexdecillion', 'septendecillion', 'octodecillion', 'novemdecillion', 'vigintillion'
			);
			$num_length = strlen($num);
			$levels = (int) (($num_length + 2) / 3);
			$max_length = $levels * 3;
			$num = substr('00' . $num, -$max_length);
			$num_levels = str_split($num, 3);
			for ($i = 0; $i < count($num_levels); $i++) {
				$levels--;
				$hundreds = (int) ($num_levels[$i] / 100);
				$hundreds = ($hundreds ? ' ' . $list1[$hundreds] . ' hundred' . ( $hundreds == 1 ? '' : '' ) . ' ' : '');
				$tens = (int) ($num_levels[$i] % 100);
				$singles = '';
				if ( $tens < 20 ) {
					$tens = ($tens ? ' and ' . $list1[$tens] . ' ' : '' );
				} elseif ($tens >= 20) {
					$tens = (int)($tens / 10);
					$tens = ' and ' . $list2[$tens] . ' ';
					$singles = (int) ($num_levels[$i] % 10);
					$singles = ' ' . $list1[$singles] . ' ';
				}
				$words[] = $hundreds . $tens . $singles . ( ( $levels && ( int ) ( $num_levels[$i] ) ) ? ' ' . $list3[$levels] . ' ' : '' );
			} //end for loop
			$commas = count($words);
			if ($commas > 1) {
				$commas = $commas - 1;
			}
			$words = implode(' ',  $words);
			$words = preg_replace('/^\s\b(and)/', '', $words );
			$words = trim($words);
			$words = ucfirst($words);
			$words = $words;
			return $words;
		}
?> 


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-1252">
</head>
	<script type="text/javascript" src="number_to_words/numberToWords.min.js"></script>
<body>
	<table border="0" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
		<tr>
			<td style="background-color:#c2bebe;"><div align="center"><b>APPROVAL FOR DIRECT PURCHASE METHOD</b></div></td>
		</tr>
		<tr>
			<td style="background-color:#c2bebe;"><div align="center"><b><?php echo $a3; ?></b></div></td>
		</tr>
		<tr>
			<td>
			<p style="text-align:justify;">The Senior Assistant Registrar[Examination]  has requested 01 No Heavy Duty Sptapler Machine  for the Exam Papers Stapling usage. The Existing  Stapler Machine which is using for exam branch  has broken down while printing papers. Immediately  request for due to  printing Exam Papers(BIT) Stepling. Therefore highly needed to this requirement for exam branch.Therefore your approval is sought for   purchase new heavy duty Stapler Machine from  
			<?php echo $a4; ?>  by  Direct  purchase method.</p>
			</td>
		</tr>
	</table>
	<br>
	<br>
	
	<table border="1" style=" border: 1px solid black;border-collapse: collapse;" width="100%">
								<thead>
									<tr>
										<th width="5%">S/No</th>
										<th width="50%">Item</th>
										<th width="15%">Qty</th>
										<th width="15%">Unit Price Without VAT (Rs) </th>
										<th width="15%">Total Amount Without VAT </th>
									</tr>
								</thead>
								<tbody>
									<?php
										$r=0;
										$sql9="SELECT * FROM direct_item_master WHERE dir_master_key='$_GET[p]' AND status=0";
										$result9 = mysqli_query($link,$sql9);
										while($row9=mysqli_fetch_array($result9)){
											
											$r++;

									?>	
											
														<tr>
																<td> <?php echo $r;?></td>
																<td> <?php echo $row9['item_name'];?></td>
																<td align="right"><?php echo $row9['qty']?></td>
																<td align="right"><?php echo number_format($row9['unit_price'],2);?></td>
																<td align="right"><?php echo number_format($row9['total_amount'] ,2);?></td>
														</tr>
									<?php	
										}
									?>
									<?php
										$sql2="SELECT SUM(vat)AS totvat,SUM(total_amount)AS totamu FROM direct_item_master WHERE dir_master_key='$_GET[p]' AND status=0";
										$result2 = mysqli_query($link,$sql2);
										while($row2=mysqli_fetch_array($result2)){
												$totvat=$row2['totvat'];
												$totamu=$row2['totamu'];
										}
										
										$totwithtax=$totvat+$totamu;
									?>
									
									<tr>
										<td colspan="4" align="center"> 15% VAT</td>
										<td align="right"><?php echo number_format($totvat,2);?></td>
									</tr>
									<tr>
										<td colspan="4" align="center"><b> Grand Total with Taxes (Rs)</b></td>
										<td align="right"><b><?php echo number_format($totwithtax,2);?></b></td>
									</tr>
								</tbody>
	</table>
	<br>
	<br>
	
</body>
</html>

<?php
  header("Content-type: application/vnd.ms-word");
  header("Content-Disposition: attachment;Filename=DirectPurchasing_TEC_Report_".$a2.".doc");   
?>