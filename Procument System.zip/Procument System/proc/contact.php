<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	<h2>Contact Us</h2>
	<p>E-mail : harshana.sanjeewa@gmail.com </br>
	Mob. +94 773 700 883</p>

	
</div>

<?php include("includes/footer.php");?>

</body>
</html>