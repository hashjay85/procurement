<?php include("includes/conn.php");?>
<?php
	session_start();
	if (isset($_POST['btn_login']) && !empty($_POST['txt_username']) && !empty($_POST['txt_password'])) {
           
        $username=$_POST['txt_username'];
        $password=MD5($_POST['txt_password']);
        
        $username=stripslashes($username);
        $password=stripslashes($password);
        
        $username = mysqli_real_escape_string($link,$username);
        $password = mysqli_real_escape_string($link,$password);
      
		$sql = "SELECT * FROM user_master WHERE user_name = '$username' and password = '$password' and status=0";
		$result = mysqli_query($link,$sql);
		while($row=mysqli_fetch_array($result)){
     
		   $unme=$row['user_name'];
		   $pass=$row['password'];
		   $ukey=$row['user_key'];
		   $user_level=$row['user_level'];
		   $department=$row['department'];
		   $committee=$row['committee'];
		 
		}
    
		if($unme == $username && $pass == $password){
			if($password=="8af95fe2ab1a54b488ef8efb3f3b0797"){ //9900
                    $flag="true";
                    $_SESSION['login_user'] = $username;
                    $_SESSION['user_level'] = $user_level;
					$_SESSION['user_keye'] = $ukey;
					$_SESSION['dep'] = $department;
					$_SESSION['committ'] = $committee;
					
				
                     header("location:newpassword.php");
                    session_register("username","user_level","user_keye","dep","committ");
            }
            else{
                    $_SESSION['login_user'] = $username;
                    $_SESSION['user_level'] = $user_level;
					$_SESSION['user_keye'] = $ukey;
					$_SESSION['dep'] = $department;
					$_SESSION['committ'] = $committee;
					
                    header("location:home.php");
                   session_register("username","user_level","user_keye","dep","committ");
            }
        }
		else{
			
				echo "<script>
						alert('Your UserName or Password is invalid.');
						window.location.href='Index.php';
					</script>";	
		}
		
	}
	else{
        
		
        
	}

?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
   <!--Made with love by Mutiullah Samim -->
   
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	

</head>
<body>


<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Sign In</h3>
				<div class="d-flex justify-content-end social_icon">
					<span><i class="fab fa-facebook-square"></i></span>
					<span><i class="fab fa-google-plus-square"></i></span>
					<span><i class="fab fa-twitter-square"></i></span>
				</div>
			</div>
			<div class="card-body">
				<form name="f1" method="post">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="username" name="txt_username" required>
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="password" name="txt_password" required>
					</div>
					<div class="row align-items-center remember">
						<input type="checkbox">Remember Me
					</div>
					<div class="form-group">
						<input type="submit" value="Login" class="btn float-right login_btn" name="btn_login">
					</div>
				</form>
			</div>
			<div class="card-footer">
				<div class="d-flex justify-content-center links">
					Don't have an account?<a href="reg.php">Sign Up</a>
				</div>
				<div class="d-flex justify-content-center">
					<a href="#">Forgot your password?</a>
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>