<?php 
include("includes/a_config.php");
include("includes/conn.php");
include("includes/sessionconfig.php");?>


<?php
	if(isset($_POST['btn_remove'])){
		$nm1=$_POST['txt_remove'];
		
		$sql1="UPDATE project_master SET status=1,remove_reason='$nm1' WHERE projmas_key='$_GET[p]'";
		if(mysqli_query($link,$sql1)){
				echo "<script>
					alert('Delete Successfully');
					window.location.href='home.php';
				</script>";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>


<div class="container" id="main-content">
	<?php
	if(isset($_GET['p']) && isset($_GET['t'])){
		
		$sql3="SELECT * FROM project_master WHERE projmas_key='$_GET[p]'";
		$result3 = mysqli_query($link,$sql3);
		while($row3=mysqli_fetch_array($result3)){	
			$p_id=$row3['project_id'];
			$p_nme=$row3['project_nme'];
			
		}
		
	?>
	<h3 align="center"><?php echo $p_id;?></h3>
	<h3 align="center"><?php echo $p_nme;?></h3>
	
	<?php
	if($_GET['t']=='NCB'){
	?>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="documentation.php?p=<?php echo $_GET['p']; ?>&t=NCB" target="_blank">
							<button class="btn btn-primary btn-md btn-block">Documentation</button>
						</a>
				</div>
			</div>
	</div>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="ncb_specification_upload.php?p=<?php echo $_GET['p']; ?>&t=NCB" target="_blank">
							<button class="btn btn-success btn-md btn-block">Specification</button>
						</a>
				</div>
			</div>
	</div>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="ncb_report.php?p=<?php echo $_GET['p'];?>" target="_blank">
							<button class="btn btn-info btn-md btn-block">Download NCB Bidding Document</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="ncb_report_advertiestment.php?p=<?php echo $_GET['p'];?>" target="_blank">
							<button class="btn btn-info btn-md btn-block">Download NCB Advertisement</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="upload_documents.php?p=<?php echo $_GET['p'];?>&t=NCB" target="_blank">
							<button class="btn btn-warning btn-md btn-block">Correct And Upload NCB Bidding Document</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="bid_process.php?p=<?php echo $_GET['p'];?>&t=NCB" target="_blank">
							<button class="btn btn-primary btn-md btn-block">Bid Process</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="bidEvaluation.php?p=<?php echo $_GET['p'];?>&t=NCB" target="_blank">
							<button class="btn btn-success btn-md btn-block">Bid Evaluation</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="ncbbid_eveluation_report.php?p=<?php echo $_GET['p'];?>" target="_blank">
							<button class="btn btn-info btn-md btn-block">Download NCB Bid Evaluation Report</button>
						</a>
				</div>
			</div>
	</div>
	
	

<?php
	}
	if($_GET['t']=='Shopping'){
?>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="documentation.php?p=<?php echo $_GET['p']; ?>&t=Shopping" target="_blank">
							<button class="btn btn-primary btn-md btn-block">Documentation</button>
						</a>
				</div>
			</div>
	</div>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="shp_specification_upload.php?p=<?php echo $_GET['p']; ?>&t=Shopping" target="_blank">
							<button class="btn btn-success btn-md btn-block">Specification</button>
						</a>
				</div>
			</div>
	</div>
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="shopping_report.php?p=<?php echo $_GET['p'];?>" target="_blank">
							<button class="btn btn-info btn-md btn-block">Download Shopping Bidding Document</button>
						</a>
				</div>
			</div>
	</div>

	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="upload_documents.php?p=<?php echo $_GET['p'];?>&t=Shopping" target="_blank">
							<button class="btn btn-warning btn-md btn-block">Correct And Upload Shopping Bidding Document</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="shp_bid_process.php?p=<?php echo $_GET['p'];?>&t=Shopping" target="_blank">
							<button class="btn btn-primary btn-md btn-block">Bid Process</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="shp_bidEvaluation.php?p=<?php echo $_GET['p'];?>&t=Shopping" target="_blank">
							<button class="btn btn-success btn-md btn-block">Bid Evaluation</button>
						</a>
				</div>
			</div>
	</div>
	
	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<div class="form-group">
						<a href="shpbid_eveluation_report.php?p=<?php echo $_GET['p'];?>" target="_blank">
							<button class="btn btn-info btn-md btn-block">Download Shopping Bid Evaluation Report</button>
						</a>
				</div>
			</div>
	</div>


<?php
	}
?>

	<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<form name="f1" method="post">	
					<section class="panel panel-primary panel-transparent">
						<div class="panel-body">
							<div class="form-group">
								<label for="sel1">Remove Reason</label>
								<textarea class="form-control input-sm" name="txt_remove" required></textarea>
							</div>
							<div class="form-group">
								
								<button type="submit" class="btn btn-danger btn-block" name="btn_remove">Remove</button>
							</div>
						</div>
					</section>
				</form>
			</div>
	</div>
<?php
	}
?>
</div>
<?php include("includes/footer.php");?>
<script>

var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

function inWords (num) {
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + ' milion ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
    return str;
}

document.getElementById('amount').onkeyup = function () {
    document.getElementById('words').innerHTML = inWords(document.getElementById('amount').value);
};



</script>

<script type="text/javascript">

$(window).scroll(function() {
  sessionStorage.scrollTop = $(this).scrollTop();
});

$(document).ready(function() {
  if (sessionStorage.scrollTop != "undefined") {
    $(window).scrollTop(sessionStorage.scrollTop);
  }
});

</script>
</body>
</html>