<div class="footer">
	&copy; <?php print date("Y");?>
	<p> Procurement Management System </br> Harshana Jayasekara </p>
</div>